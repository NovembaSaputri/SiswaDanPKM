<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Publik: siswa mengisi data sendiri tanpa login (hanya bisa menambah).
$routes->get('/', 'Daftar::index');
$routes->get('daftar', 'Daftar::index');
$routes->post('daftar', 'Daftar::kirim');
$routes->get('daftar/selesai', 'Daftar::selesai');

// Login admin.
$routes->get('loginpage', 'Loginpage::index');
$routes->post('loginpage', 'Loginpage::masuk');
$routes->post('keluar', 'Loginpage::keluar');

// Admin: wajib login. Tambah, ubah, hapus, dan unduh Excel.
$routes->group('siswa', ['filter' => 'auth'], static function (RouteCollection $routes) {
    $routes->get('/', 'Siswa::index');
    $routes->post('simpan', 'Siswa::store');
    $routes->get('ekspor', 'Siswa::export');
    $routes->get('ubah/(:num)', 'Siswa::edit/$1');
    $routes->post('perbarui/(:num)', 'Siswa::update/$1');
    $routes->post('hapus/(:num)', 'Siswa::delete/$1');
});
