<?php

namespace App\Commands;

use App\Models\PenggunaModel;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * Membuat akun admin baru, atau mengatur ulang kata sandi akun yang sudah ada.
 *
 *     php spark pengguna:buat admin "Nama Admin"
 */
class BuatPengguna extends BaseCommand
{
    protected $group       = 'Siswa';
    protected $name        = 'pengguna:buat';
    protected $description = 'Membuat akun admin, atau mengatur ulang kata sandinya bila nama pengguna sudah ada.';
    protected $usage       = 'pengguna:buat <username> [nama]';
    protected $arguments   = [
        'username' => 'Nama pengguna untuk login (3-50 karakter: huruf kecil, angka, titik, garis bawah, atau strip).',
        'nama'     => 'Nama yang ditampilkan di halaman admin (opsional).',
    ];

    public function run(array $params)
    {
        $username = strtolower(trim((string) ($params[0] ?? '')));
        if (preg_match('/^[a-z0-9._-]{3,50}$/', $username) !== 1) {
            CLI::error('Nama pengguna harus 3-50 karakter: huruf kecil, angka, titik, garis bawah, atau strip.');
            CLI::write('Contoh: php spark pengguna:buat admin "Nama Admin"');

            return EXIT_USER_INPUT;
        }

        $nama  = trim((string) ($params[1] ?? ''));
        $nama  = $nama !== '' ? $nama : $username;
        $sandi = $this->sandiAcak(12);

        $model = new PenggunaModel();
        $ada   = $model->where('username', $username)->first();

        if ($ada) {
            $model->update($ada['id'], ['password_hash' => password_hash($sandi, PASSWORD_DEFAULT)]);
            CLI::write('Kata sandi untuk "' . $username . '" sudah diatur ulang.', 'green');
        } else {
            $model->insert(['username' => $username, 'nama' => $nama, 'role' => 'admin', 'password_hash' => password_hash($sandi, PASSWORD_DEFAULT)]);
            CLI::write('Akun "' . $username . '" dibuat.', 'green');
        }

        CLI::newLine();
        CLI::write('  Nama pengguna : ' . $username);
        CLI::write('  Kata sandi    : ' . $sandi, 'yellow');
        CLI::newLine();
        CLI::write('Catat kata sandi ini sekarang. Kata sandi tidak disimpan dalam bentuk yang bisa dibaca dan tidak akan ditampilkan lagi.');

        return EXIT_SUCCESS;
    }

    /**
     * Kata sandi acak tanpa huruf yang mudah tertukar (0/O, 1/l/I).
     */
    private function sandiAcak(int $panjang): string
    {
        $huruf = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
        $hasil = '';
        for ($i = 0; $i < $panjang; $i++) {
            $hasil .= $huruf[random_int(0, strlen($huruf) - 1)];
        }

        return $hasil;
    }
}
