<?php

namespace App\Database\Seeds;

use App\Libraries\GeneratorSiswa;
use CodeIgniter\CLI\CLI;
use CodeIgniter\Database\Seeder;

/**
 * Mengisi tabel `siswa` dengan 2.600 data palsu yang tersebar rata di kelas 1 sampai 12K.
 *
 *     php spark db:seed SiswaDummySeeder
 *
 * Hanya berjalan bila tabel masih kosong, supaya data asli tidak tercampur.
 */
class SiswaDummySeeder extends Seeder
{
    private const JUMLAH = 2600;

    public function run(): void
    {
        $ada = $this->db->table('siswa')->countAllResults();
        if ($ada > 0) {
            CLI::error('Tabel siswa sudah berisi ' . $ada . ' data. Seeder dibatalkan supaya data yang ada tidak tercampur.');
            CLI::write('Kosongkan dulu tabelnya bila memang ingin memakai data dummy.', 'yellow');

            return;
        }

        $baris = (new GeneratorSiswa())->buat(self::JUMLAH);

        $this->db->transStart();
        foreach (array_chunk($baris, 500) as $bagian) {
            $this->db->table('siswa')->insertBatch($bagian);
        }
        $this->db->transComplete();

        if (! $this->db->transStatus()) {
            CLI::error('Data dummy gagal dimasukkan. Tidak ada perubahan yang disimpan.');

            return;
        }

        CLI::write(count($baris) . ' data siswa dummy berhasil dimasukkan.', 'green');
    }
}
