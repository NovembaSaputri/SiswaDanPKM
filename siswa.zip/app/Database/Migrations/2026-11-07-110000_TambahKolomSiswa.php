<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Menambah asal sekolah, jenis kelamin, tanggal lahir, dan tahun ajar.
 * Kolom dibuat boleh kosong supaya data siswa yang sudah ada tetap aman;
 * formulir tetap mewajibkan jenis kelamin, tanggal lahir, dan tahun ajar untuk data baru.
 */
class TambahKolomSiswa extends Migration
{
    public function up(): void
    {
        $this->forge->addColumn('siswa', [
            'asal_sekolah' => [
                'type'       => 'VARCHAR',
                'constraint' => 150,
                'null'       => true,
                'after'      => 'kelas',
            ],
            'jenis_kelamin' => [
                'type'       => 'CHAR',
                'constraint' => 1,
                'null'       => true,
                'after'      => 'asal_sekolah',
            ],
            'tanggal_lahir' => [
                'type'  => 'DATE',
                'null'  => true,
                'after' => 'jenis_kelamin',
            ],
            'tahun_ajar' => [
                'type'       => 'VARCHAR',
                'constraint' => 9,
                'null'       => true,
                'after'      => 'tanggal_lahir',
            ],
        ]);
    }

    public function down(): void
    {
        $this->forge->dropColumn('siswa', ['asal_sekolah', 'jenis_kelamin', 'tanggal_lahir', 'tahun_ajar']);
    }
}
