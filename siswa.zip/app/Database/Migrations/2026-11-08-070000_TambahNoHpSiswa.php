<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Menambah nomor HP (13 digit angka). Boleh kosong di database supaya siswa lama tidak terganggu;
 * formulir mewajibkannya untuk data baru. Tidak dibuat unik karena kakak-adik bisa memakai nomor orang tua yang sama.
 */
class TambahNoHpSiswa extends Migration
{
    public function up(): void
    {
        $this->forge->addColumn('siswa', [
            'no_hp' => [
                'type'       => 'CHAR',
                'constraint' => 13,
                'null'       => true,
                'after'      => 'alamat',
            ],
        ]);
    }

    public function down(): void
    {
        $this->forge->dropColumn('siswa', 'no_hp');
    }
}
