<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * - Kolom kelas diubah dari angka menjadi teks pendek supaya bisa menampung 7A sampai 12K.
 *   Nilai lama (1 sampai 6) tetap utuh.
 * - Menambah NIK (16 digit, unik) dan alamat. Keduanya boleh kosong di database
 *   supaya siswa lama tidak terganggu; formulir mewajibkannya untuk data baru.
 */
class TambahNikAlamatKelas extends Migration
{
    public function up(): void
    {
        $this->forge->modifyColumn('siswa', [
            'kelas' => [
                'type'       => 'VARCHAR',
                'constraint' => 3,
                'null'       => false,
            ],
        ]);

        $this->forge->addColumn('siswa', [
            'nik' => [
                'type'       => 'CHAR',
                'constraint' => 16,
                'null'       => true,
                'after'      => 'nama',
            ],
            'alamat' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
                'after'      => 'tahun_ajar',
            ],
        ]);

        // MySQL mengizinkan banyak nilai NULL pada kolom unik, jadi siswa lama tanpa NIK tidak bentrok.
        $this->db->query('CREATE UNIQUE INDEX siswa_nik_unik ON ' . $this->db->prefixTable('siswa') . ' (nik)');
    }

    public function down(): void
    {
        $this->db->query('DROP INDEX siswa_nik_unik ON ' . $this->db->prefixTable('siswa'));
        $this->forge->dropColumn('siswa', ['nik', 'alamat']);

        // Gagal bila sudah ada kelas 7A sampai 12K. Hapus atau ubah dulu data tersebut.
        $this->forge->modifyColumn('siswa', [
            'kelas' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'unsigned'   => true,
            ],
        ]);
    }
}
