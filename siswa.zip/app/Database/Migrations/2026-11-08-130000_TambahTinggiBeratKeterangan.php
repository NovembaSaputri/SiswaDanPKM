<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Menambah tinggi badan (cm), berat badan (kg), dan keterangan.
 * Semuanya boleh kosong di database supaya siswa lama tidak terganggu;
 * formulir mewajibkan tinggi dan berat untuk data baru, sedangkan keterangan boleh dikosongkan.
 */
class TambahTinggiBeratKeterangan extends Migration
{
    public function up(): void
    {
        $this->forge->addColumn('siswa', [
            'tinggi_badan' => [
                'type'       => 'DECIMAL',
                'constraint' => '4,1',
                'null'       => true,
                'after'      => 'no_hp',
            ],
            'berat_badan' => [
                'type'       => 'DECIMAL',
                'constraint' => '4,1',
                'null'       => true,
                'after'      => 'tinggi_badan',
            ],
            'keterangan' => [
                'type'       => 'VARCHAR',
                'constraint' => 500,
                'null'       => true,
                'after'      => 'berat_badan',
            ],
        ]);
    }

    public function down(): void
    {
        $this->forge->dropColumn('siswa', ['tinggi_badan', 'berat_badan', 'keterangan']);
    }
}
