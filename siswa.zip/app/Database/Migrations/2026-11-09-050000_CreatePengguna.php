<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Akun admin untuk halaman login. Kata sandi disimpan sebagai hash (bcrypt/argon), tidak pernah sebagai teks biasa.
 * Buat akun pertama dengan: php spark pengguna:buat admin "Nama Admin"
 */
class CreatePengguna extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'username' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],
            'nama' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
            ],
            'role' => [
                'type'       => 'VARCHAR',
                'constraint' => 20,
                'default'    => 'admin',
            ],
            'password_hash' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
            ],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('username');
        $this->forge->createTable('pengguna');
    }

    public function down(): void
    {
        $this->forge->dropTable('pengguna');
    }
}
