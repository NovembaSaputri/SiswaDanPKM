<?php

namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
    protected $table            = 'siswa';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'nama', 'nik', 'kelas', 'asal_sekolah', 'jenis_kelamin',
        'tanggal_lahir', 'tahun_ajar', 'alamat', 'no_hp', 'tinggi_badan', 'berat_badan', 'keterangan', 'foto',
    ];
    protected $useTimestamps    = true;
    protected $useAutoIncrement = true;
}
