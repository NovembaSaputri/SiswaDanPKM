<?php

namespace App\Models;

use CodeIgniter\Model;

class PenggunaModel extends Model
{
    protected $table            = 'pengguna';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $allowedFields    = ['username', 'nama', 'role', 'password_hash'];
    protected $useTimestamps    = true;
    protected $useAutoIncrement = true;
}
