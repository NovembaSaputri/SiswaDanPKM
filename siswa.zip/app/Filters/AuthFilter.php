<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Menjaga halaman admin: hanya pengguna yang sudah login lewat /loginpage yang boleh masuk.
 * Dipasang pada rute dengan ['filter' => 'auth'] (lihat app/Config/Routes.php).
 */
class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (session()->get('pengguna_id') && session()->get('pengguna_role') === 'admin') {
            return null;
        }

        // Ingat halaman yang dituju (hanya untuk GET), supaya setelah login admin kembali ke sana.
        if (strtolower($request->getMethod()) === 'get') {
            $query = $request->getUri()->getQuery();
            session()->set('tujuan', uri_string() . ($query !== '' ? '?' . $query : ''));
        }

        return redirect()->to(site_url('loginpage'))->with('galat', 'Masuk dulu untuk membuka data siswa.');
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Halaman admin berisi data pribadi: jangan disimpan di cache browser, supaya tombol "kembali" setelah keluar tidak menampilkannya.
        return $response->setHeader('Cache-Control', 'no-store, max-age=0');
    }
}
