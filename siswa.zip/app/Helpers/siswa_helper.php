<?php

if (! function_exists('inisial')) {
    /**
     * Huruf awal nama depan dan nama belakang, dipakai sebagai avatar bila siswa belum punya foto.
     */
    function inisial(string $nama): string
    {
        $bagian = preg_split('/\s+/', trim($nama), -1, PREG_SPLIT_NO_EMPTY);
        if (! $bagian) {
            return '?';
        }

        $awal  = mb_substr($bagian[0], 0, 1);
        $akhir = count($bagian) > 1 ? mb_substr(end($bagian), 0, 1) : '';

        return mb_strtoupper($awal . $akhir);
    }
}

if (! function_exists('tanggal_indo')) {
    /**
     * Mengubah 2018-03-12 menjadi "12 Maret 2018".
     */
    function tanggal_indo(?string $tanggal): string
    {
        if (! $tanggal) {
            return '-';
        }

        $bulan = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
        ];
        $waktu = strtotime($tanggal);
        if ($waktu === false) {
            return '-';
        }

        return date('j', $waktu) . ' ' . $bulan[(int) date('n', $waktu)] . ' ' . date('Y', $waktu);
    }
}

if (! function_exists('label_jk')) {
    function label_jk(?string $jk): string
    {
        return match ($jk) {
            'L'     => 'Laki-laki',
            'P'     => 'Perempuan',
            default => '-',
        };
    }
}

if (! function_exists('tahun_ajar_sekarang')) {
    /**
     * Tahun ajar baru dimulai bulan Juli: Agustus 2026 termasuk 2026/2027, Mei 2026 masih 2025/2026.
     */
    function tahun_ajar_sekarang(): string
    {
        $tahun = (int) date('Y');
        $mulai = (int) date('n') >= 7 ? $tahun : $tahun - 1;

        return $mulai . '/' . ($mulai + 1);
    }
}

if (! function_exists('daftar_tahun_ajar')) {
    /**
     * Pilihan tahun ajar untuk formulir: satu tahun ke depan sampai lima tahun ke belakang, terbaru di atas.
     *
     * @return list<string>
     */
    function daftar_tahun_ajar(): array
    {
        $mulai = (int) substr(tahun_ajar_sekarang(), 0, 4);
        $daftar = [];
        for ($i = $mulai + 1; $i >= $mulai - 5; $i--) {
            $daftar[] = $i . '/' . ($i + 1);
        }

        return $daftar;
    }
}

if (! function_exists('daftar_kelas')) {
    /**
     * Pilihan kelas untuk formulir, dikelompokkan: kelas 1-6, lalu 7A-7K sampai 12A-12K.
     *
     * @return array<string,list<string>>
     */
    function daftar_kelas(): array
    {
        $grup = ['SD (Kelas 1-6)' => ['1', '2', '3', '4', '5', '6']];
        for ($t = 7; $t <= 12; $t++) {
            $grup['Kelas ' . $t] = array_map(static fn (string $r) => $t . $r, range('A', 'K'));
        }

        return $grup;
    }
}

if (! function_exists('semua_kelas')) {
    /**
     * Semua kode kelas yang sah dalam satu daftar datar, berurutan dari 1 sampai 12K.
     *
     * @return list<string>
     */
    function semua_kelas(): array
    {
        return array_merge(...array_values(daftar_kelas()));
    }
}

if (! function_exists('tingkat_kelas')) {
    /**
     * Tingkat dari kode kelas: "7A" menjadi 7, "12K" menjadi 12, "3" menjadi 3.
     */
    function tingkat_kelas(?string $kelas): int
    {
        return (int) $kelas;
    }
}
