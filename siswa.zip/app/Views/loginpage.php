<?php
$galat = session()->getFlashdata('galat');
$pesan = session()->getFlashdata('pesan');
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <title>Masuk Admin - Data Siswa</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500&display=swap">
    <link rel="stylesheet" href="<?= base_url('css/siswa.css') ?>">
</head>
<body class="auth">
<main class="auth-card">
    <div>
        <h1>Masuk admin</h1>
        <p class="sub">Khusus admin sekolah untuk mengelola data siswa.</p>
    </div>

    <?php if ($pesan): ?><p class="notice" role="status"><?= esc($pesan) ?></p><?php endif ?>
    <?php if ($galat): ?><p class="errors" role="alert"><?= esc($galat) ?></p><?php endif ?>

    <form action="<?= site_url('loginpage') ?>" method="post">
        <?= csrf_field() ?>
        <div>
            <label class="lbl" for="username">Nama pengguna</label>
            <input type="text" id="username" name="username" autocomplete="username" autocapitalize="none" maxlength="50" value="<?= esc((string) old('username'), 'attr') ?>" required autofocus>
        </div>
        <div>
            <label class="lbl" for="sandi">Kata sandi</label>
            <div class="pw-row">
                <input type="password" id="sandi" name="sandi" autocomplete="current-password" maxlength="200" required>
                <button type="button" class="btn small" id="lihat" aria-pressed="false">Lihat</button>
            </div>
        </div>
        <button type="submit" class="btn primary">Masuk</button>
    </form>

    <p class="auth-foot">Siswa yang ingin mengisi data sendiri? <a href="<?= site_url('daftar') ?>">Buka formulir pengisian</a>.</p>
</main>
<script>
(function () {
    var b = document.getElementById('lihat'), i = document.getElementById('sandi');
    b.addEventListener('click', function () {
        var tampil = i.type === 'password';
        i.type = tampil ? 'text' : 'password';
        b.textContent = tampil ? 'Sembunyikan' : 'Lihat';
        b.setAttribute('aria-pressed', tampil ? 'true' : 'false');
    });
})();
</script>
</body>
</html>
