<?php
/**
 * @var list<array<string,mixed>> $rows
 * @var \CodeIgniter\Pager\Pager  $pager
 * @var array<int,int>            $jumlah
 * @var array<string,mixed>|null  $edit
 * @var int                       $tingkat
 * @var string                    $kelas
 * @var string                    $q
 * @var string                    $tahun
 * @var string                    $sekolah
 * @var list<string>              $daftarTahun
 * @var list<array<string,mixed>> $daftarSekolah
 * @var int                       $tanpaSekolah
 * @var string                    $tanpaKode
 * @var array<string,int>         $jumlahKelas
 * @var list<string>              $opsiTahun
 * @var bool                      $adaData
 */
$pesan  = session()->getFlashdata('pesan');
$errors = session()->getFlashdata('errors') ?? [];
$total  = array_sum($jumlah);

// Kelas awal formulir: kelas yang sedang difilter, atau tingkat 1-6 bila tab SD yang aktif.
$kelasAwal = $kelas !== '' ? $kelas : (($tingkat >= 1 && $tingkat <= 6) ? (string) $tingkat : '');
$action    = $edit ? site_url('siswa/perbarui/' . $edit['id']) : site_url('siswa/simpan');

// Alamat daftar dengan filter yang sedang aktif, kecuali bagian yang diganti.
$parameter = static function (array $ganti = []) use ($q, $tahun, $sekolah, $tingkat, $kelas): array {
    $p = array_merge(['q' => $q, 'tahun' => $tahun, 'sekolah' => $sekolah, 'tingkat' => $tingkat ?: '', 'kelas' => $kelas], $ganti);

    return array_filter($p, static fn ($v) => $v !== '' && $v !== null && $v !== 0);
};
$url = static function (array $ganti = []) use ($parameter): string {
    $p = $parameter($ganti);

    return site_url('siswa') . ($p ? '?' . http_build_query($p) : '');
};
// Unduhan Excel memakai filter yang sama persis dengan daftar yang sedang tampil.
$urlEkspor = site_url('siswa/ekspor') . ($parameter() ? '?' . http_build_query($parameter()) : '');
$jumlahHasil = $pager->getTotal();

// Ringkasan filter untuk label total dan pesan kosong.
$ringkas = [];
if ($kelas !== '') {
    $ringkas[] = 'kelas ' . $kelas;
} elseif ($tingkat > 0) {
    $ringkas[] = 'kelas ' . $tingkat;
}
if ($tahun !== '') {
    $ringkas[] = 'tahun ajar ' . $tahun;
}
if ($sekolah === $tanpaKode) {
    $ringkas[] = 'tanpa asal sekolah';
} elseif ($sekolah !== '') {
    $ringkas[] = 'asal ' . $sekolah;
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Siswa</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500&display=swap">
    <link rel="stylesheet" href="<?= base_url('css/siswa.css') ?>">
</head>
<body>
<div class="wrap">
    <header class="top">
        <div>
            <h1>Data Siswa</h1>
            <p class="sub">Catat identitas, foto, kelas 1 sampai 12, asal sekolah, dan tahun ajar.</p>
        </div>
        <div class="total">
            <b><?= $total ?></b>
            <span>siswa<?= $ringkas ? ' ' . esc(implode(', ', $ringkas)) : ' terdaftar' ?></span>
        </div>
    </header>

    <div class="userbar">
        <span>Masuk sebagai <b><?= esc(session()->get('pengguna_nama') ?? '') ?></b></span>
        <a class="btn small" href="<?= site_url('daftar') ?>" target="_blank" rel="noopener">Buka formulir publik</a>
        <form action="<?= site_url('keluar') ?>" method="post">
            <?= csrf_field() ?>
            <button type="submit" class="btn small">Keluar</button>
        </form>
    </div>

    <?php if ($pesan): ?>
        <p class="notice" role="status"><?= esc($pesan) ?></p>
    <?php endif ?>

    <div class="layout">
        <form class="panel" action="<?= $action ?>" method="post" enctype="multipart/form-data" autocomplete="off" id="form-siswa">
            <?= csrf_field() ?>
            <h2><?= $edit ? 'Ubah data siswa' : 'Tambah siswa' ?></h2>

            <?php if ($errors): ?>
                <ul class="errors" role="alert">
                    <?php foreach ($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach ?>
                </ul>
            <?php endif ?>

            <?= view('siswa/_isian', [
                'edit'      => $edit,
                'kelasAwal' => $kelasAwal,
                'tahunAwal' => $tahun,
                'opsiTahun' => $opsiTahun,
            ]) ?>

            <div class="actions">
                <button type="submit" class="btn primary"><?= $edit ? 'Simpan perubahan' : 'Simpan siswa' ?></button>
                <?php if ($edit): ?>
                    <a class="btn" href="<?= site_url('siswa') ?>">Batal</a>
                <?php endif ?>
            </div>
        </form>

        <section class="list-area" aria-label="Daftar siswa">
            <div class="toolbar">
                <form method="get" action="<?= site_url('siswa') ?>" class="search">
                    <label class="lbl" for="q">Cari nama, NIK, atau nomor HP</label>
                    <div class="search-row">
                        <input type="search" id="q" name="q" placeholder="Ketik nama, NIK, atau nomor HP" value="<?= esc($q, 'attr') ?>">
                        <select name="kelas" aria-label="Filter kelas">
                            <option value="">Semua kelas</option>
                            <?php foreach (daftar_kelas() as $grup => $isi): ?>
                                <?php $ada = array_filter($isi, static fn ($k) => isset($jumlahKelas[$k])); ?>
                                <?php if ($ada): ?>
                                    <optgroup label="<?= esc($grup, 'attr') ?>">
                                        <?php foreach ($ada as $k): ?>
                                            <option value="<?= $k ?>" <?= $k === $kelas ? 'selected' : '' ?>><?= $k ?> (<?= $jumlahKelas[$k] ?>)</option>
                                        <?php endforeach ?>
                                    </optgroup>
                                <?php endif ?>
                            <?php endforeach ?>
                        </select>
                        <select name="tahun" aria-label="Filter tahun ajar">
                            <option value="">Semua tahun ajar</option>
                            <?php foreach ($daftarTahun as $t): ?>
                                <option value="<?= esc($t, 'attr') ?>" <?= $t === $tahun ? 'selected' : '' ?>><?= esc($t) ?></option>
                            <?php endforeach ?>
                        </select>
                        <select name="sekolah" aria-label="Filter asal sekolah">
                            <option value="">Semua asal sekolah</option>
                            <?php foreach ($daftarSekolah as $s): ?>
                                <option value="<?= esc($s['nama'], 'attr') ?>" <?= $s['nama'] === $sekolah ? 'selected' : '' ?>><?= esc($s['nama']) ?> (<?= (int) $s['jumlah'] ?>)</option>
                            <?php endforeach ?>
                            <?php if ($tanpaSekolah > 0): ?>
                                <option value="<?= esc($tanpaKode, 'attr') ?>" <?= $sekolah === $tanpaKode ? 'selected' : '' ?>>Tanpa asal sekolah (<?= $tanpaSekolah ?>)</option>
                            <?php endif ?>
                        </select>
                        <button type="submit" class="btn">Terapkan</button>
                    </div>
                </form>

                <nav class="tabs" aria-label="Filter tingkat kelas">
                    <a class="tab" href="<?= $url(['tingkat' => '', 'kelas' => '']) ?>" aria-pressed="<?= $tingkat === 0 ? 'true' : 'false' ?>">
                        Semua <span class="n"><?= $total ?></span>
                    </a>
                    <?php for ($k = 1; $k <= 12; $k++): ?>
                        <a class="tab" data-k="<?= $k ?>" style="--c: var(--c<?= $k ?>)"
                           href="<?= $url(['tingkat' => $k, 'kelas' => '']) ?>"
                           aria-pressed="<?= $tingkat === $k ? 'true' : 'false' ?>">
                            Kelas <?= $k ?> <span class="n"><?= $jumlah[$k] ?></span>
                        </a>
                    <?php endfor ?>
                </nav>

                <div class="export-row">
                    <?php if ($jumlahHasil > 0): ?>
                        <a class="btn" href="<?= esc($urlEkspor, 'attr') ?>">Unduh Excel (<?= number_format($jumlahHasil, 0, ',', '.') ?> siswa)</a>
                        <span class="hint">Berisi semua siswa yang sesuai filter di atas, bukan hanya halaman ini.</span>
                    <?php else: ?>
                        <span class="btn" aria-disabled="true">Unduh Excel</span>
                        <span class="hint">Belum ada siswa yang sesuai filter.</span>
                    <?php endif ?>
                </div>
            </div>

            <?php if (! $adaData): ?>
                <div class="empty">
                    <strong>Belum ada siswa</strong>
                    <p>Isi data di formulir untuk mendaftarkan siswa pertama.</p>
                </div>
            <?php elseif (! $rows): ?>
                <div class="empty">
                    <strong>Tidak ada hasil</strong>
                    <p>
                        <?= $q !== '' ? 'Tidak ada siswa dengan nama, NIK, atau nomor HP "' . esc($q) . '"' : 'Belum ada siswa' ?>
                        <?= $ringkas ? 'untuk ' . esc(implode(', ', $ringkas)) : 'di daftar' ?>.
                    </p>
                </div>
            <?php else: ?>
                <div class="grid">
                    <?php foreach ($rows as $s): ?>
                        <?php $t = tingkat_kelas($s['kelas']); ?>
                        <article class="card">
                            <div class="who">
                                <div class="avatar" style="--c: var(--c<?= $t ?>)">
                                    <?php if (! empty($s['foto'])): ?>
                                        <img src="<?= esc(base_url('uploads/siswa/' . $s['foto']), 'attr') ?>" alt="">
                                    <?php else: ?>
                                        <?= esc(inisial($s['nama'])) ?>
                                    <?php endif ?>
                                </div>
                                <div class="txt">
                                    <div class="name"><?= esc($s['nama']) ?></div>
                                    <span class="badge" style="--c: var(--c<?= $t ?>)">Kelas <?= esc($s['kelas']) ?></span>
                                </div>
                            </div>

                            <dl class="meta">
                                <div><dt>NIK</dt><dd class="mono"><?= esc($s['nik'] ?: '-') ?></dd></div>
                                <div><dt>Jenis kelamin</dt><dd><?= esc(label_jk($s['jenis_kelamin'] ?? null)) ?></dd></div>
                                <div><dt>Tanggal lahir</dt><dd><?= esc(tanggal_indo($s['tanggal_lahir'] ?? null)) ?></dd></div>
                                <div><dt>Asal sekolah</dt><dd><?= esc($s['asal_sekolah'] ?: '-') ?></dd></div>
                                <div><dt>Alamat</dt><dd><?= esc($s['alamat'] ?: '-') ?></dd></div>
                                <div><dt>Nomor HP</dt><dd class="mono"><?= esc($s['no_hp'] ?: '-') ?></dd></div>
                                <div><dt>Tinggi badan</dt><dd class="mono"><?= ($s['tinggi_badan'] ?? '') !== '' ? esc(number_format((float) $s['tinggi_badan'], 1, ',', '.')) . ' cm' : '-' ?></dd></div>
                                <div><dt>Berat badan</dt><dd class="mono"><?= ($s['berat_badan'] ?? '') !== '' ? esc(number_format((float) $s['berat_badan'], 1, ',', '.')) . ' kg' : '-' ?></dd></div>
                                <div><dt>Keterangan</dt><dd><?= esc($s['keterangan'] ?: '-') ?></dd></div>
                                <div><dt>Tahun ajar</dt><dd class="mono"><?= esc($s['tahun_ajar'] ?: '-') ?></dd></div>
                            </dl>

                            <div class="actions">
                                <a class="btn small" href="<?= site_url('siswa/ubah/' . $s['id']) ?>">Ubah</a>
                                <form action="<?= site_url('siswa/hapus/' . $s['id']) ?>" method="post"
                                      onsubmit="return confirm('Hapus data <?= esc($s['nama'], 'js') ?>?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="btn small danger">Hapus</button>
                                </form>
                            </div>
                        </article>
                    <?php endforeach ?>
                </div>

                <?php if ($pager->getPageCount() > 1): ?>
                    <?= $pager->links() ?>
                <?php endif ?>
            <?php endif ?>
        </section>
    </div>
</div>

</body>
</html>
