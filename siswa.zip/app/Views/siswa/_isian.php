<?php
/**
 * Kolom isian siswa, dipakai bersama oleh formulir admin (siswa/index) dan formulir publik (daftar).
 *
 * @var array<string,mixed>|null $edit        Data siswa yang sedang diubah, atau null untuk formulir baru.
 * @var string                   $kelasAwal   Kelas yang terpilih di awal (formulir baru).
 * @var string                   $tahunAwal   Tahun ajar yang terpilih di awal (formulir baru).
 * @var list<string>             $opsiTahun   Pilihan tahun ajar.
 */
$edit      = $edit ?? null;
$kelasIsi  = (string) old('kelas', $edit['kelas'] ?? ($kelasAwal ?? ''));
$namaIsi   = (string) old('nama', $edit['nama'] ?? '');
$nikIsi    = (string) old('nik', $edit['nik'] ?? '');
$asalIsi   = (string) old('asal_sekolah', $edit['asal_sekolah'] ?? '');
$jkIsi     = (string) old('jenis_kelamin', $edit['jenis_kelamin'] ?? '');
$lahirIsi  = (string) old('tanggal_lahir', $edit['tanggal_lahir'] ?? '');
$tahunIsi  = (string) old('tahun_ajar', $edit['tahun_ajar'] ?? (($tahunAwal ?? '') !== '' ? $tahunAwal : tahun_ajar_sekarang()));
$alamatIsi = (string) old('alamat', $edit['alamat'] ?? '');
$hpIsi     = (string) old('no_hp', $edit['no_hp'] ?? '');
$tinggiIsi = (string) old('tinggi_badan', isset($edit['tinggi_badan']) ? (string) (float) $edit['tinggi_badan'] : '');
$beratIsi  = (string) old('berat_badan', isset($edit['berat_badan']) ? (string) (float) $edit['berat_badan'] : '');
$ketIsi    = (string) old('keterangan', $edit['keterangan'] ?? '');
$fotoEdit  = $edit['foto'] ?? null;

// Tahun ajar milik data lama yang sudah di luar rentang tetap bisa dipilih saat mengubah.
$pilihanTahun = $opsiTahun;
if ($tahunIsi !== '' && ! in_array($tahunIsi, $pilihanTahun, true)) {
    $pilihanTahun[] = $tahunIsi;
}
?>
            <div>
                <label class="lbl" for="nama">Nama lengkap</label>
                <input type="text" id="nama" name="nama" maxlength="100" placeholder="Contoh: Putri Ayu Lestari" value="<?= esc($namaIsi, 'attr') ?>" required>
            </div>

            <div>
                <label class="lbl" for="nik">NIK</label>
                <input type="text" id="nik" name="nik" inputmode="numeric" maxlength="16" pattern="[0-9]{16}" placeholder="16 digit angka" value="<?= esc($nikIsi, 'attr') ?>" required>
            </div>

            <fieldset>
                <legend>Jenis kelamin</legend>
                <div class="chips two" role="radiogroup" aria-label="Jenis kelamin">
                    <input type="radio" name="jenis_kelamin" id="jk-l" value="L" <?= $jkIsi === 'L' ? 'checked' : '' ?> required>
                    <label class="chip wide" for="jk-l" style="--c: var(--accent)">Laki-laki</label>
                    <input type="radio" name="jenis_kelamin" id="jk-p" value="P" <?= $jkIsi === 'P' ? 'checked' : '' ?> required>
                    <label class="chip wide" for="jk-p" style="--c: var(--accent)">Perempuan</label>
                </div>
            </fieldset>

            <div class="row2">
                <div>
                    <label class="lbl" for="tanggal_lahir">Tanggal lahir</label>
                    <input type="date" id="tanggal_lahir" name="tanggal_lahir" value="<?= esc($lahirIsi, 'attr') ?>" max="<?= date('Y-m-d') ?>" required>
                </div>
                <div>
                    <label class="lbl" for="tahun_ajar">Tahun ajar</label>
                    <select id="tahun_ajar" name="tahun_ajar" required>
                        <?php foreach ($pilihanTahun as $t): ?>
                            <option value="<?= esc($t, 'attr') ?>" <?= $t === $tahunIsi ? 'selected' : '' ?>><?= esc($t) ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>

            <div>
                <label class="lbl" for="kelas-pilih">Kelas</label>
                <div class="kelas-row">
                    <span class="kelas-dot" id="kelas-dot" style="--c: var(--c<?= $kelasIsi !== '' ? tingkat_kelas($kelasIsi) : 'x' ?>)"></span>
                    <select id="kelas-pilih" name="kelas" required>
                        <option value="">Pilih kelas</option>
                        <?php foreach (daftar_kelas() as $grup => $isi): ?>
                            <optgroup label="<?= esc($grup, 'attr') ?>">
                                <?php foreach ($isi as $k): ?>
                                    <option value="<?= $k ?>" <?= $k === $kelasIsi ? 'selected' : '' ?>>Kelas <?= $k ?></option>
                                <?php endforeach ?>
                            </optgroup>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>

            <div>
                <label class="lbl" for="asal_sekolah">Asal sekolah</label>
                <input type="text" id="asal_sekolah" name="asal_sekolah" maxlength="150" placeholder="Contoh: SD Negeri 1 Melati" value="<?= esc($asalIsi, 'attr') ?>">
                <p class="hint">Boleh dikosongkan. Isi nama TK atau sekolah sebelumnya.</p>
            </div>

            <div>
                <label class="lbl" for="alamat">Alamat</label>
                <textarea id="alamat" name="alamat" rows="3" maxlength="255" placeholder="Jalan, RT/RW, kelurahan, kecamatan, kota" required><?= esc($alamatIsi) ?></textarea>
            </div>

            <div>
                <label class="lbl" for="no_hp">Nomor HP</label>
                <input type="text" id="no_hp" name="no_hp" class="mono-in" inputmode="numeric" maxlength="13" pattern="[0-9]{13}" placeholder="13 digit angka, contoh 6281234567890" value="<?= esc($hpIsi, 'attr') ?>" required>
            </div>

            <div class="row2">
                <div>
                    <label class="lbl" for="tinggi_badan">Tinggi badan (cm)</label>
                    <input type="number" id="tinggi_badan" name="tinggi_badan" class="mono-in" inputmode="decimal" min="50" max="250" step="0.1" placeholder="Contoh: 125.5" value="<?= esc($tinggiIsi, 'attr') ?>" required>
                </div>
                <div>
                    <label class="lbl" for="berat_badan">Berat badan (kg)</label>
                    <input type="number" id="berat_badan" name="berat_badan" class="mono-in" inputmode="decimal" min="5" max="250" step="0.1" placeholder="Contoh: 28.4" value="<?= esc($beratIsi, 'attr') ?>" required>
                </div>
            </div>

            <div>
                <label class="lbl" for="keterangan">Keterangan</label>
                <textarea id="keterangan" name="keterangan" rows="3" maxlength="500" placeholder="Catatan tambahan, misalnya alergi, kacamata, atau beasiswa"><?= esc($ketIsi) ?></textarea>
                <p class="hint">Boleh dikosongkan.</p>
            </div>

            <div>
                <span class="lbl">Foto</span>
                <div class="photo-row">
                    <div class="avatar" id="prev" style="--c: var(--c<?= $kelasIsi !== '' ? tingkat_kelas($kelasIsi) : 'x' ?>)">
                        <?php if ($fotoEdit): ?>
                            <img src="<?= esc(base_url('uploads/siswa/' . $fotoEdit), 'attr') ?>" alt="">
                        <?php else: ?>
                            <?= esc(inisial($namaIsi)) ?>
                        <?php endif ?>
                    </div>
                    <div class="photo-actions">
                        <label class="btn file-btn" for="foto">Pilih foto<input type="file" id="foto" name="foto" accept="image/*"></label>
                        <?php if ($fotoEdit): ?>
                            <label class="check"><input type="checkbox" name="hapus_foto" value="1"> Hapus foto</label>
                        <?php endif ?>
                    </div>
                </div>
                <p class="hint">Foto dipotong persegi dan dikecilkan otomatis. Maksimal 4 MB.</p>
            </div>

<script>
// Pratinjau foto, inisial, dan warna kelas langsung di formulir sebelum disimpan.
(function () {
    var input = document.getElementById('foto');
    var prev = document.getElementById('prev');
    var nama = document.getElementById('nama');
    var nik = document.getElementById('nik');
    var kelas = document.getElementById('kelas-pilih');
    var dot = document.getElementById('kelas-dot');
    var adaFoto = !!prev.querySelector('img');

    function inisial(v) {
        var p = v.trim().split(/\s+/).filter(Boolean);
        if (!p.length) return '?';
        return (p[0].charAt(0) + (p.length > 1 ? p[p.length - 1].charAt(0) : '')).toUpperCase();
    }
    function warna() {
        var t = parseInt(kelas.value, 10);
        var v = t ? 'var(--c' + t + ')' : 'var(--cx)';
        prev.style.setProperty('--c', v);
        dot.style.setProperty('--c', v);
    }
    input.addEventListener('change', function () {
        var f = input.files && input.files[0];
        if (!f) return;
        var url = URL.createObjectURL(f);
        prev.textContent = '';
        var img = document.createElement('img');
        img.alt = '';
        img.src = url;
        prev.appendChild(img);
        adaFoto = true;
    });
    nama.addEventListener('input', function () {
        if (adaFoto) return;
        prev.textContent = inisial(nama.value);
    });
    nik.addEventListener('input', function () { nik.value = nik.value.replace(/\D/g, '').slice(0, 16); });
    var hp = document.getElementById('no_hp');
    hp.addEventListener('input', function () { hp.value = hp.value.replace(/\D/g, '').slice(0, 13); });
    kelas.addEventListener('change', warna);
    warna();
})();
</script>
