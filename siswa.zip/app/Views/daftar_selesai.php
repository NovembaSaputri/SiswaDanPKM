<?php /** @var array{nama:string,kelas:string,tahun:string} $s */ ?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Terkirim</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500&display=swap">
    <link rel="stylesheet" href="<?= base_url('css/siswa.css') ?>">
</head>
<body>
<div class="public-wrap">
    <section class="panel thanks">
        <div class="tick" aria-hidden="true">&#10003;</div>
        <h2>Terima kasih, data sudah terkirim</h2>
        <p class="sub">
            <?= esc($s['nama']) ?><?= ($s['kelas'] ?? '') !== '' ? ', kelas ' . esc($s['kelas']) : '' ?><?= ($s['tahun'] ?? '') !== '' ? ', tahun ajar ' . esc($s['tahun']) : '' ?>.
            Kalau ada yang salah, hubungi admin sekolah.
        </p>
        <div class="actions"><a class="btn" href="<?= site_url('daftar') ?>">Isi data siswa lain</a></div>
    </section>
</div>
</body>
</html>
