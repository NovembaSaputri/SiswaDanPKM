<?php
/** @var list<string> $opsiTahun */
$errors = session()->getFlashdata('errors') ?? [];
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Isi Data Siswa</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500&display=swap">
    <link rel="stylesheet" href="<?= base_url('css/siswa.css') ?>">
</head>
<body>
<div class="public-wrap">
    <header>
        <h1>Isi data siswa</h1>
        <p class="sub">Isi datamu dengan benar, lalu kirim. Tidak perlu login. Data yang sudah terkirim hanya bisa diubah oleh admin sekolah.</p>
    </header>

    <form class="panel" action="<?= site_url('daftar') ?>" method="post" enctype="multipart/form-data" autocomplete="off" id="form-siswa">
        <?= csrf_field() ?>

        <?php if ($errors): ?>
            <ul class="errors" role="alert">
                <?php foreach ($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach ?>
            </ul>
        <?php endif ?>

        <?= view('siswa/_isian', [
            'edit'      => null,
            'kelasAwal' => '',
            'tahunAwal' => '',
            'opsiTahun' => $opsiTahun,
        ]) ?>

        <div class="hp-field" aria-hidden="true">
            <label for="situs">Jangan diisi</label>
            <input type="text" id="situs" name="situs" tabindex="-1" autocomplete="off">
        </div>

        <div class="actions">
            <button type="submit" class="btn primary">Kirim data</button>
        </div>
    </form>

    <p class="auth-foot">Admin sekolah? <a href="<?= site_url('loginpage') ?>">Masuk di sini</a>.</p>
</div>
</body>
</html>
