<?php

namespace App\Controllers;

use App\Models\PenggunaModel;
use CodeIgniter\HTTP\RedirectResponse;

/**
 * Halaman login admin: /loginpage
 */
class Loginpage extends BaseController
{
    private const BATAS_GAGAL = 5;     // percobaan salah berturut-turut
    private const KUNCI_MENIT = 15;    // lama terkunci

    /** Hash bcrypt dari teks acak. Dipakai agar waktu respons sama, baik nama pengguna ada maupun tidak. */
    private const HASH_PALSU = '$2y$10$eImiTXuWVxfM37uY4JANjQ6ZxNf5G8Yq1lq1mSxX1Y7yq5N2r4Q8e';

    public function index(): string|RedirectResponse
    {
        if (session()->get('pengguna_id')) {
            return redirect()->to(site_url('siswa'));
        }

        helper('form');

        return view('loginpage');
    }

    public function masuk(): RedirectResponse
    {
        helper('form');

        $aturan = [
            'username' => 'required|max_length[50]',
            'sandi'    => 'required|max_length[200]',
        ];
        if (! $this->validate($aturan, [
            'username' => ['required' => 'Isi nama pengguna.', 'max_length' => 'Nama pengguna terlalu panjang.'],
            'sandi'    => ['required' => 'Isi kata sandi.', 'max_length' => 'Kata sandi terlalu panjang.'],
        ])) {
            return redirect()->back()->withInput()->with('galat', implode(' ', $this->validator->getErrors()));
        }

        $username = strtolower(trim((string) $this->request->getPost('username')));
        $sandi    = (string) $this->request->getPost('sandi');

        // Batasi tebakan kata sandi: setelah beberapa kali salah, kunci sementara untuk kombinasi nama pengguna dan alamat IP ini.
        $kunci  = 'login_gagal_' . md5($username . '|' . $this->request->getIPAddress());
        $gagal  = (int) cache($kunci);
        if ($gagal >= self::BATAS_GAGAL) {
            return redirect()->back()->withInput()->with('galat', 'Terlalu banyak percobaan yang salah. Coba lagi dalam ' . self::KUNCI_MENIT . ' menit.');
        }

        $model    = new PenggunaModel();
        $pengguna = $model->where('username', $username)->first();
        $hash     = $pengguna['password_hash'] ?? self::HASH_PALSU;
        $cocok    = password_verify($sandi, $hash) && $pengguna !== null && ($pengguna['role'] ?? '') === 'admin';

        if (! $cocok) {
            cache()->save($kunci, $gagal + 1, self::KUNCI_MENIT * 60);

            return redirect()->back()->withInput()->with('galat', 'Nama pengguna atau kata sandi salah.');
        }

        cache()->delete($kunci);

        // Hash lama diperbarui otomatis bila algoritma bawaan PHP sudah berganti.
        if (password_needs_rehash($pengguna['password_hash'], PASSWORD_DEFAULT)) {
            $model->update($pengguna['id'], ['password_hash' => password_hash($sandi, PASSWORD_DEFAULT)]);
        }

        // ID sesi diganti setelah login supaya sesi yang dibuat sebelumnya (misalnya oleh penyerang) tidak ikut berlaku.
        $tujuan = (string) session()->get('tujuan');
        session()->regenerate(true);
        session()->set(['pengguna_id' => (int) $pengguna['id'], 'pengguna_nama' => $pengguna['nama'], 'pengguna_role' => $pengguna['role']]);
        session()->remove('tujuan');

        // Hanya mengarahkan ke halaman admin; alamat lain diabaikan agar tidak bisa dipakai untuk membelokkan ke situs luar.
        if (preg_match('#^siswa(/[A-Za-z0-9_\-]+)*(\?[^\s]*)?$#', $tujuan) === 1) {
            return redirect()->to(site_url($tujuan));
        }

        return redirect()->to(site_url('siswa'));
    }

    public function keluar(): RedirectResponse
    {
        session()->destroy();

        return redirect()->to(site_url('loginpage'))->with('pesan', 'Kamu sudah keluar.');
    }
}
