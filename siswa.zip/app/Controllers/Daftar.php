<?php

namespace App\Controllers;

use App\Libraries\FormSiswa;
use App\Models\SiswaModel;
use CodeIgniter\HTTP\RedirectResponse;

/**
 * Halaman publik: siswa mengisi datanya sendiri tanpa login (/daftar).
 * Halaman ini hanya bisa menambah data. Melihat, mengubah, menghapus, dan mengunduh hanya untuk admin.
 */
class Daftar extends BaseController
{
    use FormSiswa;

    /** Batas kiriman per alamat IP per jam. Cukup longgar supaya satu kelas yang memakai wifi sekolah yang sama tidak terblokir. */
    private const BATAS_PER_JAM = 60;

    public function index(): string
    {
        helper(['form', 'siswa']);

        return view('daftar', ['opsiTahun' => daftar_tahun_ajar()]);
    }

    public function kirim(): RedirectResponse
    {
        helper(['form', 'siswa']);

        // Kolom jebakan: manusia tidak melihatnya dan membiarkannya kosong, sedangkan bot biasanya mengisi semua kolom.
        // Bot tetap diberi halaman "terima kasih" supaya tidak tahu kiriman mereka dibuang.
        if (trim((string) $this->request->getPost('situs')) !== '') {
            return redirect()->to(site_url('daftar/selesai'))->with('selesai', ['nama' => 'Data kamu', 'kelas' => '', 'tahun' => '']);
        }

        $kunci  = 'daftar_' . md5($this->request->getIPAddress());
        $jumlah = (int) cache($kunci);
        if ($jumlah >= self::BATAS_PER_JAM) {
            return redirect()->back()->withInput()->with('errors', ['batas' => 'Terlalu banyak data dikirim dari jaringan ini. Coba lagi dalam satu jam.']);
        }

        if ($gagal = $this->periksa(null, true)) {
            return $gagal;
        }

        $data         = $this->dataForm();
        $data['foto'] = $this->simpanFoto();

        (new SiswaModel())->insert($data);
        cache()->save($kunci, $jumlah + 1, 3600);

        return redirect()->to(site_url('daftar/selesai'))->with('selesai', [
            'nama'  => $data['nama'],
            'kelas' => $data['kelas'],
            'tahun' => $data['tahun_ajar'],
        ]);
    }

    public function selesai(): string|RedirectResponse
    {
        $selesai = session()->getFlashdata('selesai');
        if (! is_array($selesai)) {
            return redirect()->to(site_url('daftar'));
        }

        return view('daftar_selesai', ['s' => $selesai]);
    }
}
