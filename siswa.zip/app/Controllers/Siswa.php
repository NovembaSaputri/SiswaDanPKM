<?php

namespace App\Controllers;

use App\Libraries\FormSiswa;
use App\Libraries\XlsxWriter;
use App\Models\SiswaModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\RedirectResponse;
use CodeIgniter\HTTP\ResponseInterface;

class Siswa extends BaseController
{
    use FormSiswa;

    private const TANPA_SEKOLAH = '__kosong';

    /**
     * Daftar siswa dengan formulir tambah di sisi kiri.
     */
    public function index(): string
    {
        return $this->halaman(null);
    }

    /**
     * Daftar siswa dengan formulir terisi data siswa yang diubah.
     */
    public function edit(int $id): string
    {
        return $this->halaman($this->cari($id));
    }

    public function store(): RedirectResponse
    {
        if ($gagal = $this->periksa(null)) {
            return $gagal;
        }

        $data         = $this->dataForm();
        $data['foto'] = $this->simpanFoto();

        (new SiswaModel())->insert($data);

        return redirect()
            ->to(site_url('siswa') . '?' . http_build_query(['tingkat' => tingkat_kelas($data['kelas']), 'tahun' => $data['tahun_ajar']]))
            ->with('pesan', $data['nama'] . ' ditambahkan ke Kelas ' . $data['kelas'] . ' tahun ajar ' . $data['tahun_ajar'] . '.');
    }

    public function update(int $id): RedirectResponse
    {
        $siswa = $this->cari($id);

        if ($gagal = $this->periksa($id)) {
            return $gagal;
        }

        $data = $this->dataForm();

        $fotoBaru = $this->simpanFoto();
        if ($fotoBaru !== null) {
            $this->hapusFile($siswa['foto']);
            $data['foto'] = $fotoBaru;
        } elseif ($this->request->getPost('hapus_foto')) {
            $this->hapusFile($siswa['foto']);
            $data['foto'] = null;
        }

        (new SiswaModel())->update($id, $data);

        return redirect()->to(site_url('siswa'))->with('pesan', 'Perubahan data ' . $data['nama'] . ' disimpan.');
    }

    public function delete(int $id): RedirectResponse
    {
        $siswa = $this->cari($id);

        $this->hapusFile($siswa['foto']);
        (new SiswaModel())->delete($id);

        return redirect()->back()->with('pesan', 'Data ' . $siswa['nama'] . ' dihapus.');
    }

    /* ---------------------------------------------------------------- */

    private function halaman(?array $edit): string
    {
        helper(['form', 'siswa']);

        $f = $this->ambilFilter();
        ['kelas' => $kelas, 'tingkat' => $tingkat, 'q' => $q, 'tahun' => $tahun, 'sekolah' => $sekolah] = $f;

        $model = new SiswaModel();
        $this->terapkanFilter($model, $f);
        $rows = $this->urutkan($model)->paginate(24);

        // Jumlah per tingkat mengikuti filter tahun ajar dan asal sekolah, supaya angka di tab sesuai dengan daftar.
        $hitung = new SiswaModel();
        if ($tahun !== '') {
            $hitung->where('tahun_ajar', $tahun);
        }
        $this->filterSekolah($hitung, $sekolah);
        $jumlah = array_fill(1, 12, 0);
        $baris  = $hitung
            ->select('CAST(kelas AS UNSIGNED) AS tingkat, COUNT(*) AS jumlah', false)
            ->groupBy('CAST(kelas AS UNSIGNED)', false)
            ->findAll();
        foreach ($baris as $b) {
            if (isset($jumlah[(int) $b['tingkat']])) {
                $jumlah[(int) $b['tingkat']] = (int) $b['jumlah'];
            }
        }

        $daftarTahun = array_column(
            (new SiswaModel())->select('tahun_ajar')->distinct()->where('tahun_ajar IS NOT NULL')->orderBy('tahun_ajar', 'DESC')->findAll(),
            'tahun_ajar'
        );

        // MySQL membandingkan tanpa membedakan huruf besar kecil, jadi "TK Melati" dan "tk melati" digabung menjadi satu sekolah.
        $daftarSekolah = (new SiswaModel())
            ->select('asal_sekolah AS nama, COUNT(*) AS jumlah')
            ->where("asal_sekolah IS NOT NULL AND asal_sekolah <> ''")
            ->groupBy('asal_sekolah')
            ->orderBy('asal_sekolah', 'ASC')
            ->findAll();

        $tanpaSekolah = (new SiswaModel())
            ->groupStart()->where('asal_sekolah', null)->orWhere('asal_sekolah', '')->groupEnd()
            ->countAllResults();

        // Kelas yang sudah punya siswa, untuk dropdown filter kelas.
        $jumlahKelas = [];
        foreach ((new SiswaModel())->select('kelas, COUNT(*) AS jumlah')->groupBy('kelas')->findAll() as $b) {
            $jumlahKelas[$b['kelas']] = (int) $b['jumlah'];
        }

        return view('siswa/index', [
            'rows'          => $rows,
            'pager'         => $model->pager,
            'jumlah'        => $jumlah,
            'edit'          => $edit,
            'tingkat'       => $tingkat,
            'kelas'         => $kelas,
            'q'             => $q,
            'tahun'         => $tahun,
            'sekolah'       => $sekolah,
            'daftarTahun'   => $daftarTahun,
            'daftarSekolah' => $daftarSekolah,
            'tanpaSekolah'  => $tanpaSekolah,
            'tanpaKode'     => self::TANPA_SEKOLAH,
            'jumlahKelas'   => $jumlahKelas,
            'opsiTahun'     => daftar_tahun_ajar(),
            'adaData'       => (new SiswaModel())->countAllResults() > 0,
        ]);
    }

    /**
     * Membaca filter dari alamat (URL). Dipakai bersama oleh daftar dan ekspor Excel, supaya hasil keduanya selalu sama.
     *
     * Tab memilih satu tingkat (1-12). Dropdown kelas memilih satu kelas persis, misalnya 7A, dan menang atas tab.
     *
     * @return array{kelas:string,tingkat:int,q:string,tahun:string,sekolah:string}
     */
    private function ambilFilter(): array
    {
        helper('siswa');

        $kelas = trim((string) $this->request->getGet('kelas'));
        if (! in_array($kelas, semua_kelas(), true)) {
            $kelas = '';
        }

        $tingkat = (int) $this->request->getGet('tingkat');
        if ($kelas !== '') {
            $tingkat = tingkat_kelas($kelas);
        } elseif ($tingkat < 1 || $tingkat > 12) {
            $tingkat = 0;
        }

        $tahun = (string) $this->request->getGet('tahun');
        if (! preg_match('#^\d{4}/\d{4}$#', $tahun)) {
            $tahun = '';
        }

        $sekolah = trim((string) $this->request->getGet('sekolah'));
        if (mb_strlen($sekolah) > 150) {
            $sekolah = '';
        }

        return [
            'kelas'   => $kelas,
            'tingkat' => $tingkat,
            'q'       => trim((string) $this->request->getGet('q')),
            'tahun'   => $tahun,
            'sekolah' => $sekolah,
        ];
    }

    /**
     * @param array{kelas:string,tingkat:int,q:string,tahun:string,sekolah:string} $f
     */
    private function terapkanFilter(SiswaModel $model, array $f): void
    {
        $this->terapkanKelas($model, $f['kelas'], $f['tingkat']);
        if ($f['tahun'] !== '') {
            $model->where('tahun_ajar', $f['tahun']);
        }
        $this->filterSekolah($model, $f['sekolah']);
        if ($f['q'] !== '') {
            $model->groupStart()->like('nama', $f['q'])->orLike('nik', $f['q'])->orLike('no_hp', $f['q'])->groupEnd();
        }
    }

    private function urutkan(SiswaModel $model): SiswaModel
    {
        return $model
            ->orderBy('CAST(kelas AS UNSIGNED)', 'ASC', false)
            ->orderBy('kelas', 'ASC')
            ->orderBy('nama', 'ASC');
    }

    /**
     * Mengunduh file Excel berisi semua siswa yang lolos filter aktif (bukan hanya halaman yang sedang tampil).
     */
    public function export(): ResponseInterface
    {
        helper('siswa');

        $f     = $this->ambilFilter();
        $model = new SiswaModel();
        $this->terapkanFilter($model, $f);
        $data = $this->urutkan($model)->findAll();

        $kolom = [
            ['judul' => 'No', 'lebar' => 6, 'tipe' => 'n'],
            ['judul' => 'Nama', 'lebar' => 30, 'tipe' => 't'],
            ['judul' => 'NIK', 'lebar' => 20, 'tipe' => 't'],
            ['judul' => 'Kelas', 'lebar' => 8, 'tipe' => 't'],
            ['judul' => 'Tahun Ajar', 'lebar' => 12, 'tipe' => 't'],
            ['judul' => 'Jenis Kelamin', 'lebar' => 15, 'tipe' => 't'],
            ['judul' => 'Tanggal Lahir', 'lebar' => 18, 'tipe' => 'd'],
            ['judul' => 'Asal Sekolah', 'lebar' => 30, 'tipe' => 't'],
            ['judul' => 'Alamat', 'lebar' => 60, 'tipe' => 't'],
            ['judul' => 'Nomor HP', 'lebar' => 16, 'tipe' => 't'],
            ['judul' => 'Tinggi Badan (cm)', 'lebar' => 18, 'tipe' => 'n'],
            ['judul' => 'Berat Badan (kg)', 'lebar' => 17, 'tipe' => 'n'],
            ['judul' => 'Keterangan', 'lebar' => 50, 'tipe' => 't'],
        ];

        $baris = [];
        foreach ($data as $i => $s) {
            $baris[] = [
                $i + 1,
                $s['nama'],
                $s['nik'],
                $s['kelas'],
                $s['tahun_ajar'],
                label_jk($s['jenis_kelamin']) === '-' ? null : label_jk($s['jenis_kelamin']),
                $s['tanggal_lahir'],
                $s['asal_sekolah'],
                $s['alamat'],
                $s['no_hp'],
                $s['tinggi_badan'],
                $s['berat_badan'],
                $s['keterangan'],
            ];
        }

        $isi = (new XlsxWriter())->buat('Data Siswa', $kolom, $baris);

        // Nama file memuat filter yang dipakai, misalnya data-siswa_kelas-7A_2026-2027_2026-11-08.xlsx
        $bagian = ['data-siswa'];
        if ($f['kelas'] !== '') {
            $bagian[] = 'kelas-' . $f['kelas'];
        } elseif ($f['tingkat'] > 0) {
            $bagian[] = 'kelas-' . $f['tingkat'];
        }
        if ($f['tahun'] !== '') {
            $bagian[] = str_replace('/', '-', $f['tahun']);
        }
        if ($f['sekolah'] !== '') {
            $bagian[] = $f['sekolah'] === self::TANPA_SEKOLAH ? 'tanpa-asal-sekolah' : 'sekolah';
        }
        $bagian[] = date('Y-m-d');
        $nama     = implode('_', $bagian) . '.xlsx';

        return $this->response
            ->setContentType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $nama . '"')
            ->setHeader('Cache-Control', 'no-store')
            ->setBody($isi);
    }

    /**
     * Membatasi daftar pada satu kelas persis (7A), atau satu tingkat (7 berarti 7A sampai 7K).
     */
    private function terapkanKelas(SiswaModel $model, string $kelas, int $tingkat): void
    {
        if ($kelas !== '') {
            $model->where('kelas', $kelas);
        } elseif ($tingkat >= 1 && $tingkat <= 6) {
            $model->where('kelas', (string) $tingkat);
        } elseif ($tingkat >= 7) {
            $model->like('kelas', (string) $tingkat, 'after');
        }
    }

    /**
     * Membatasi daftar pada satu asal sekolah. Nilai khusus menampilkan siswa yang asal sekolahnya kosong.
     */
    private function filterSekolah(SiswaModel $model, string $sekolah): void
    {
        if ($sekolah === '') {
            return;
        }

        if ($sekolah === self::TANPA_SEKOLAH) {
            $model->groupStart()->where('asal_sekolah', null)->orWhere('asal_sekolah', '')->groupEnd();

            return;
        }

        $model->where('asal_sekolah', $sekolah);
    }

    private function cari(int $id): array
    {
        $siswa = (new SiswaModel())->find($id);
        if ($siswa === null) {
            throw PageNotFoundException::forPageNotFound('Data siswa tidak ditemukan.');
        }

        return $siswa;
    }
}
