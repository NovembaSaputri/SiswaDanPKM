<?php

namespace App\Libraries;

use RuntimeException;
use ZipArchive;

/**
 * Pembuat file Excel (.xlsx) sederhana tanpa pustaka tambahan. Hanya butuh ekstensi PHP `zip`.
 *
 * Nilai sel:
 *  - string  : disimpan sebagai teks, jadi NIK dan nomor HP tidak berubah menjadi angka ilmiah
 *  - int/float: disimpan sebagai angka
 *  - ['tanggal' => 'Y-m-d'] : disimpan sebagai tanggal Excel, selalu tampil dd/mm/yyyy
 *  - null    : sel kosong
 *
 * Contoh:
 *     $x = new XlsxWriter();
 *     $x->tambahSheet('Data', [['Nama', 'NIK'], ['Budi', '3174010101100001']], [24, 20]);
 *     $biner = $x->hasil();
 */
class XlsxWriter
{
    /** Gaya sel: 0 biasa, 1 judul kolom, 2 tanggal, 3 teks (rata kiri, apa adanya) */
    private const GAYA_JUDUL   = 1;
    private const GAYA_TANGGAL = 2;

    /** @var list<array{nama:string,baris:list<list<mixed>>,lebar:list<float|int>}> */
    private array $sheet = [];

    /**
     * @param list<list<mixed>>   $baris Baris pertama dianggap judul kolom.
     * @param list<float|int>     $lebar Lebar tiap kolom dalam karakter.
     */
    public function tambahSheet(string $nama, array $baris, array $lebar = []): self
    {
        $nama = trim((string) preg_replace('/[\\\\\/\?\*\[\]:]/', ' ', $nama));
        $nama = mb_substr($nama === '' ? 'Sheet' . (count($this->sheet) + 1) : $nama, 0, 31);

        $this->sheet[] = ['nama' => $nama, 'baris' => $baris, 'lebar' => $lebar];

        return $this;
    }

    /**
     * Jalan pintas untuk satu sheet dengan definisi kolom, dipakai Siswa::export().
     *
     * @param list<array{judul:string,lebar:int|float,tipe:string}> $kolom tipe: 'n' angka, 't' teks, 'd' tanggal (Y-m-d)
     * @param list<list<mixed>>                                      $baris
     */
    public function buat(string $namaSheet, array $kolom, array $baris): string
    {
        $isi = [array_column($kolom, 'judul')];
        foreach ($baris as $b) {
            $sel = [];
            foreach ($kolom as $i => $k) {
                $nilai = $b[$i] ?? null;
                if ($nilai === null || $nilai === '') {
                    $sel[] = null;
                } elseif ($k['tipe'] === 'n') {
                    $sel[] = is_numeric($nilai) ? $nilai + 0 : null;
                } elseif ($k['tipe'] === 'd') {
                    $sel[] = ['tanggal' => (string) $nilai];
                } else {
                    $sel[] = (string) $nilai;
                }
            }
            $isi[] = $sel;
        }

        return $this->tambahSheet($namaSheet, $isi, array_column($kolom, 'lebar'))->hasil();
    }

    public function hasil(): string
    {
        if (! class_exists(ZipArchive::class)) {
            throw new RuntimeException('Ekstensi PHP zip belum aktif, file Excel tidak bisa dibuat.');
        }
        if ($this->sheet === []) {
            throw new RuntimeException('Belum ada sheet.');
        }

        $tmp = tempnam(sys_get_temp_dir(), 'xlsx');
        $zip = new ZipArchive();
        if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('File sementara tidak bisa dibuat.');
        }

        $zip->addFromString('[Content_Types].xml', $this->tipeKonten());
        $zip->addFromString('_rels/.rels', $this->relasiUtama());
        $zip->addFromString('xl/workbook.xml', $this->workbook());
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->relasiWorkbook());
        $zip->addFromString('xl/styles.xml', $this->gaya());
        foreach ($this->sheet as $i => $s) {
            $zip->addFromString('xl/worksheets/sheet' . ($i + 1) . '.xml', $this->xmlSheet($s['baris'], $s['lebar']));
        }
        $zip->close();

        $isi = (string) file_get_contents($tmp);
        @unlink($tmp);

        return $isi;
    }

    /* ------------------------------------------------------------ */

    private function xmlSheet(array $baris, array $lebar): string
    {
        $kolomTerbanyak = 1;
        foreach ($baris as $b) {
            $kolomTerbanyak = max($kolomTerbanyak, count($b));
        }
        $akhir = $this->huruf($kolomTerbanyak) . max(1, count($baris));

        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<dimension ref="A1:' . $akhir . '"/>'
            . '<sheetViews><sheetView workbookViewId="0">'
            . '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
            . '</sheetView></sheetViews>'
            . '<sheetFormatPr defaultRowHeight="15"/>';

        if ($lebar) {
            $xml .= '<cols>';
            foreach ($lebar as $i => $w) {
                $xml .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . $w . '" customWidth="1"/>';
            }
            $xml .= '</cols>';
        }

        $xml .= '<sheetData>';
        foreach ($baris as $r => $sel) {
            $nomor = $r + 1;
            $xml  .= '<row r="' . $nomor . '">';
            foreach ($sel as $c => $nilai) {
                $xml .= $this->sel($this->huruf($c + 1) . $nomor, $nilai, $r === 0);
            }
            $xml .= '</row>';
        }
        $xml .= '</sheetData>';

        if (count($baris) > 1) {
            $xml .= '<autoFilter ref="A1:' . $akhir . '"/>';
        }

        return $xml . '</worksheet>';
    }

    /**
     * @param mixed $nilai
     */
    private function sel(string $ref, $nilai, bool $judul): string
    {
        if ($nilai === null || $nilai === '') {
            return '';
        }

        $gaya = $judul ? ' s="' . self::GAYA_JUDUL . '"' : '';

        if (is_array($nilai) && isset($nilai['tanggal'])) {
            $serial = $this->serialTanggal((string) $nilai['tanggal']);
            if ($serial === null) {
                return '';
            }

            return '<c r="' . $ref . '" s="' . self::GAYA_TANGGAL . '"><v>' . $serial . '</v></c>';
        }

        if (is_int($nilai) || is_float($nilai)) {
            return '<c r="' . $ref . '"' . $gaya . '><v>' . $nilai . '</v></c>';
        }

        return '<c r="' . $ref . '"' . $gaya . ' t="inlineStr"><is><t xml:space="preserve">' . $this->aman((string) $nilai) . '</t></is></c>';
    }

    /**
     * Hari sejak 30 Desember 1899, sesuai sistem tanggal Excel.
     */
    private function serialTanggal(string $tanggal): ?int
    {
        $d = \DateTimeImmutable::createFromFormat('!Y-m-d', $tanggal);
        if ($d === false) {
            return null;
        }

        return (int) (new \DateTimeImmutable('1899-12-30'))->diff($d)->format('%r%a');
    }

    private function aman(string $teks): string
    {
        // Karakter kontrol tidak sah di XML dan membuat Excel menolak file.
        $teks = (string) preg_replace('/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', '', $teks);

        return htmlspecialchars($teks, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private function huruf(int $kolom): string
    {
        $h = '';
        while ($kolom > 0) {
            $sisa  = ($kolom - 1) % 26;
            $h     = chr(65 + $sisa) . $h;
            $kolom = intdiv($kolom - 1, 26);
        }

        return $h;
    }

    private function tipeKonten(): string
    {
        $sheet = '';
        foreach ($this->sheet as $i => $_) {
            $sheet .= '<Override PartName="/xl/worksheets/sheet' . ($i + 1) . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . $sheet
            . '</Types>';
    }

    private function relasiUtama(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';
    }

    private function workbook(): string
    {
        $sheet = '';
        foreach ($this->sheet as $i => $s) {
            $sheet .= '<sheet name="' . $this->aman($s['nama']) . '" sheetId="' . ($i + 1) . '" r:id="rId' . ($i + 1) . '"/>';
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets>' . $sheet . '</sheets>'
            . '</workbook>';
    }

    private function relasiWorkbook(): string
    {
        $r = '';
        foreach ($this->sheet as $i => $_) {
            $r .= '<Relationship Id="rId' . ($i + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . ($i + 1) . '.xml"/>';
        }
        $r .= '<Relationship Id="rId' . (count($this->sheet) + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $r . '</Relationships>';
    }

    private function gaya(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<numFmts count="1"><numFmt numFmtId="164" formatCode="dd/mm/yyyy"/></numFmts>'
            . '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>'
            . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF1B2A4E"/><bgColor indexed="64"/></patternFill></fill></fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="3">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center"/></xf>'
            . '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="left"/></xf>'
            . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }
}
