<?php

namespace App\Libraries;

use CodeIgniter\HTTP\RedirectResponse;
use App\Models\SiswaModel;

/**
 * Logika formulir siswa yang dipakai bersama oleh halaman admin (Siswa) dan halaman publik (Daftar):
 * membaca isian, memvalidasi, dan menyimpan foto. Dipakai di controller yang punya $this->request dan $this->validate().
 */
trait FormSiswa
{
    protected function folderFoto(): string
    {
        return 'uploads/siswa';
    }

    protected function bersih(string $kolom): string
    {
        return trim((string) preg_replace('/\s+/', ' ', (string) $this->request->getPost($kolom)));
    }

    /**
     * Data teks dari formulir, sudah dirapikan. Foto ditangani terpisah.
     */
    protected function dataForm(): array
    {
        $asal = $this->bersih('asal_sekolah');
        $ket  = $this->bersih('keterangan');

        return [
            'nama'          => $this->bersih('nama'),
            'nik'           => preg_replace('/\D/', '', (string) $this->request->getPost('nik')),
            'kelas'         => (string) $this->request->getPost('kelas'),
            'asal_sekolah'  => $asal !== '' ? $asal : null,
            'jenis_kelamin' => (string) $this->request->getPost('jenis_kelamin'),
            'tanggal_lahir' => (string) $this->request->getPost('tanggal_lahir'),
            'tahun_ajar'    => (string) $this->request->getPost('tahun_ajar'),
            'alamat'        => $this->bersih('alamat'),
            'no_hp'         => preg_replace('/\D/', '', (string) $this->request->getPost('no_hp')),
            'tinggi_badan'  => $this->angka('tinggi_badan'),
            'berat_badan'   => $this->angka('berat_badan'),
            'keterangan'    => $ket !== '' ? $ket : null,
        ];
    }

    /**
     * Angka desimal dari formulir, dibulatkan ke satu angka di belakang koma. "125,5" dan "125.5" sama-sama dibaca 125.5.
     */
    protected function angka(string $kolom): ?float
    {
        $nilai = str_replace(',', '.', trim((string) $this->request->getPost($kolom)));

        return is_numeric($nilai) ? round((float) $nilai, 1) : null;
    }

    /**
     * Mengembalikan redirect berisi pesan galat bila isian tidak valid, atau null bila semuanya benar.
     * $id diisi saat mengubah data, supaya NIK milik siswa itu sendiri tidak dianggap kembar.
     */
    protected function periksa(?int $id, bool $publik = false): ?RedirectResponse
    {
        $lolos = $this->validate($this->aturan(), $this->pesan());
        $galat = $lolos ? [] : $this->validator->getErrors();

        if (! isset($galat['tanggal_lahir'])) {
            $masalah = $this->cekTanggalLahir((string) $this->request->getPost('tanggal_lahir'));
            if ($masalah !== null) {
                $galat['tanggal_lahir'] = $masalah;
            }
        }

        if (! isset($galat['nik'])) {
            $nik   = preg_replace('/\D/', '', (string) $this->request->getPost('nik'));
            $kembar = new SiswaModel();
            $kembar->where('nik', $nik);
            if ($id !== null) {
                $kembar->where('id !=', $id);
            }
            if ($kembar->countAllResults() > 0) {
                $galat['nik'] = $publik
                    ? 'NIK ini sudah terdaftar. Kalau ada data yang salah, hubungi admin sekolah untuk mengubahnya.'
                    : 'NIK ini sudah terdaftar pada siswa lain.';
            }
        }

        if ($galat === []) {
            return null;
        }

        return redirect()->back()->withInput()->with('errors', $galat);
    }

    protected function cekTanggalLahir(string $tanggal): ?string
    {
        if ($tanggal > date('Y-m-d')) {
            return 'Tanggal lahir tidak boleh di masa depan.';
        }
        if ($tanggal < date('Y-m-d', strtotime('-25 years'))) {
            return 'Tanggal lahir terlalu lama untuk siswa sekolah. Periksa tahunnya.';
        }

        return null;
    }

    protected function aturan(): array
    {
        helper('siswa');

        $aturan = [
            'nama'          => 'required|min_length[2]|max_length[100]',
            'nik'           => 'required|exact_length[16]|is_natural',
            'kelas'         => 'required|in_list[' . implode(',', semua_kelas()) . ']',
            'asal_sekolah'  => 'permit_empty|max_length[150]',
            'jenis_kelamin' => 'required|in_list[L,P]',
            'tanggal_lahir' => 'required|valid_date[Y-m-d]',
            'tahun_ajar'    => 'required|in_list[' . implode(',', daftar_tahun_ajar()) . ']',
            'alamat'        => 'required|min_length[5]|max_length[255]',
            'no_hp'         => 'required|exact_length[13]|is_natural',
            'tinggi_badan'  => 'required|decimal|greater_than_equal_to[50]|less_than_equal_to[250]',
            'berat_badan'   => 'required|decimal|greater_than_equal_to[5]|less_than_equal_to[250]',
            'keterangan'    => 'permit_empty|max_length[500]',
        ];

        // Aturan foto hanya dipasang bila ada file yang dikirim. Jangan pakai permit_empty untuk ini:
        // CodeIgniter melewati semua aturan kolom file yang tidak ada di data POST, sehingga file apa pun lolos.
        $foto = $this->request->getFile('foto');
        if ($foto !== null && $foto->getError() !== UPLOAD_ERR_NO_FILE) {
            $aturan['foto'] = 'uploaded[foto]|is_image[foto]|mime_in[foto,image/jpg,image/jpeg,image/png,image/webp]|max_size[foto,4096]';
        }

        return $aturan;
    }

    protected function pesan(): array
    {
        return [
            'nama' => [
                'required'   => 'Isi nama siswa terlebih dahulu.',
                'min_length' => 'Nama siswa minimal 2 huruf.',
                'max_length' => 'Nama siswa maksimal 100 karakter.',
            ],
            'nik' => [
                'required'     => 'Isi NIK siswa.',
                'exact_length' => 'NIK harus tepat 16 digit.',
                'is_natural'   => 'NIK hanya boleh berisi angka.',
            ],
            'kelas' => [
                'required' => 'Pilih kelas.',
                'in_list'  => 'Pilih kelas dari daftar (1 sampai 6, atau 7A sampai 12K).',
            ],
            'asal_sekolah' => [
                'max_length' => 'Asal sekolah maksimal 150 karakter.',
            ],
            'jenis_kelamin' => [
                'required' => 'Pilih jenis kelamin.',
                'in_list'  => 'Pilih jenis kelamin.',
            ],
            'tanggal_lahir' => [
                'required'   => 'Isi tanggal lahir.',
                'valid_date' => 'Tanggal lahir tidak valid.',
            ],
            'tahun_ajar' => [
                'required' => 'Pilih periode tahun ajar.',
                'in_list'  => 'Pilih periode tahun ajar dari daftar.',
            ],
            'alamat' => [
                'required'   => 'Isi alamat siswa.',
                'min_length' => 'Alamat terlalu pendek.',
                'max_length' => 'Alamat maksimal 255 karakter.',
            ],
            'no_hp' => [
                'required'     => 'Isi nomor HP.',
                'exact_length' => 'Nomor HP harus tepat 13 digit angka.',
                'is_natural'   => 'Nomor HP hanya boleh berisi angka.',
            ],
            'tinggi_badan' => [
                'required'              => 'Isi tinggi badan.',
                'decimal'               => 'Tinggi badan harus berupa angka, misalnya 125.5.',
                'greater_than_equal_to' => 'Tinggi badan minimal 50 cm. Periksa angkanya.',
                'less_than_equal_to'    => 'Tinggi badan maksimal 250 cm. Periksa angkanya.',
            ],
            'berat_badan' => [
                'required'              => 'Isi berat badan.',
                'decimal'               => 'Berat badan harus berupa angka, misalnya 32.5.',
                'greater_than_equal_to' => 'Berat badan minimal 5 kg. Periksa angkanya.',
                'less_than_equal_to'    => 'Berat badan maksimal 250 kg. Periksa angkanya.',
            ],
            'keterangan' => [
                'max_length' => 'Keterangan maksimal 500 karakter.',
            ],
            'foto' => [
                'uploaded' => 'Foto gagal diunggah. Coba pilih ulang filenya.',
                'is_image' => 'File yang dipilih bukan gambar.',
                'mime_in'  => 'Foto harus berformat JPG, PNG, atau WebP.',
                'max_size' => 'Ukuran foto maksimal 4 MB.',
            ],
        ];
    }

    /**
     * Menyimpan foto yang diunggah, dipotong persegi 256x256. Mengembalikan nama file, atau null bila tidak ada foto.
     */
    protected function simpanFoto(): ?string
    {
        $file = $this->request->getFile('foto');
        if ($file === null || $file->getError() === UPLOAD_ERR_NO_FILE || ! $file->isValid() || $file->hasMoved()) {
            return null;
        }

        $folder = FCPATH . $this->folderFoto();
        if (! is_dir($folder)) {
            mkdir($folder, 0755, true);
        }

        $nama = $file->getRandomName();
        $file->move($folder, $nama);

        try {
            $path = $folder . DIRECTORY_SEPARATOR . $nama;
            \Config\Services::image()->withFile($path)->fit(256, 256, 'center')->save($path);
        } catch (\Throwable $e) {
            log_message('warning', 'Foto tidak bisa dikecilkan: ' . $e->getMessage());
        }

        return $nama;
    }

    protected function hapusFile(?string $foto): void
    {
        if (! $foto) {
            return;
        }

        $path = FCPATH . $this->folderFoto() . DIRECTORY_SEPARATOR . basename($foto);
        if (is_file($path)) {
            @unlink($path);
        }
    }
}
