<?php

namespace App\Libraries;

/**
 * Membuat data siswa palsu untuk uji coba. Tidak bergantung pada CodeIgniter,
 * dan hasilnya selalu sama untuk $seed yang sama.
 *
 * Sebaran dibuat rata:
 * - kelas: 72 kelas (1-6, 7A-12K) mendapat jumlah siswa yang selisihnya paling banyak 1
 * - jenis kelamin: berselang-seling, jadi hampir persis 50:50 di setiap kelas
 * - tahun ajar: bergilir di antara tiga tahun ajar terakhir
 * - asal sekolah: bergilir di antara daftar sekolah sesuai jenjang kelasnya
 *
 * NIK, nama, alamat, dan nomor HP dibuat acak. Semuanya fiktif.
 */
class GeneratorSiswa
{
    private const LAKI = [
        'Ahmad', 'Muhammad', 'Budi', 'Agus', 'Rizky', 'Fajar', 'Dimas', 'Bagas', 'Arief', 'Hendra',
        'Yoga', 'Rafi', 'Farhan', 'Galih', 'Bayu', 'Eko', 'Wahyu', 'Ilham', 'Reza', 'Aditya',
        'Kevin', 'Daffa', 'Naufal', 'Zidan', 'Alif', 'Raka', 'Satria', 'Dani', 'Ivan', 'Joko',
        'Teguh', 'Andika', 'Rendra', 'Fikri', 'Gilang', 'Haris', 'Imam', 'Krisna', 'Lukman', 'Mario',
        'Nando', 'Oscar', 'Putra', 'Rangga', 'Surya', 'Taufik', 'Umar', 'Vino', 'Yusuf', 'Zaki',
    ];

    private const PEREMPUAN = [
        'Siti', 'Putri', 'Ayu', 'Dewi', 'Sari', 'Rina', 'Intan', 'Nabila', 'Salsabila', 'Aulia',
        'Citra', 'Dinda', 'Eka', 'Fitri', 'Gita', 'Hana', 'Indah', 'Jihan', 'Kirana', 'Laras',
        'Maya', 'Nadia', 'Olivia', 'Permata', 'Rani', 'Sekar', 'Tiara', 'Umi', 'Vina', 'Wulan',
        'Yasmin', 'Zahra', 'Alya', 'Bella', 'Cahya', 'Diah', 'Elsa', 'Fira', 'Gina', 'Hilda',
        'Amanda', 'Bunga', 'Chika', 'Dara', 'Endah', 'Farah', 'Githa', 'Hesti', 'Ismi', 'Jasmine',
    ];

    private const TENGAH = ['Dwi', 'Tri', 'Eka', 'Catur', 'Nur', 'Putra', 'Putri', 'Adi', 'Cahya', 'Bintang'];

    private const BELAKANG_LAKI = [
        'Pratama', 'Saputra', 'Wijaya', 'Santoso', 'Hidayat', 'Nugroho', 'Kusuma', 'Permana', 'Ramadhan', 'Setiawan',
        'Fauzi', 'Firmansyah', 'Prasetyo', 'Syahputra', 'Maulana', 'Kurniawan', 'Susanto', 'Wibowo', 'Siregar', 'Nasution',
        'Hutagalung', 'Simanjuntak', 'Sitorus', 'Lubis', 'Harahap', 'Gunawan', 'Halim', 'Darmawan', 'Mahendra', 'Alamsyah',
    ];

    private const BELAKANG_PEREMPUAN = [
        'Lestari', 'Rahayu', 'Handayani', 'Anggraini', 'Wulandari', 'Purnama', 'Maharani', 'Utami', 'Puspita', 'Safitri',
        'Ningsih', 'Fitriani', 'Kartika', 'Amelia', 'Permatasari', 'Kusumawati', 'Septiani', 'Rahmawati', 'Octaviani', 'Pertiwi',
        'Siregar', 'Nasution', 'Hutagalung', 'Simanjuntak', 'Sitorus', 'Lubis', 'Harahap', 'Salsabila', 'Andini', 'Marcellina',
    ];

    /** Nama kota, provinsi, dan kode wilayah 4 digit untuk awalan NIK. */
    private const KOTA = [
        ['Jakarta Selatan', 'DKI Jakarta', '3174'], ['Bandung', 'Jawa Barat', '3273'], ['Surabaya', 'Jawa Timur', '3578'],
        ['Semarang', 'Jawa Tengah', '3374'], ['Yogyakarta', 'DI Yogyakarta', '3471'], ['Medan', 'Sumatera Utara', '1271'],
        ['Makassar', 'Sulawesi Selatan', '7371'], ['Denpasar', 'Bali', '5171'], ['Malang', 'Jawa Timur', '3573'],
        ['Bogor', 'Jawa Barat', '3271'], ['Depok', 'Jawa Barat', '3276'], ['Tangerang', 'Banten', '3671'],
        ['Bekasi', 'Jawa Barat', '3275'], ['Palembang', 'Sumatera Selatan', '1671'], ['Balikpapan', 'Kalimantan Timur', '6471'],
    ];

    private const JALAN = [
        'Melati', 'Mawar', 'Kenanga', 'Anggrek', 'Merdeka', 'Sudirman', 'Diponegoro', 'Ahmad Yani', 'Gatot Subroto', 'Pahlawan',
        'Cendana', 'Flamboyan', 'Kamboja', 'Dahlia', 'Teratai', 'Veteran', 'Pemuda', 'Imam Bonjol', 'Hayam Wuruk', 'Gajah Mada',
        'Kartini', 'Cut Nyak Dien', 'Ki Hajar Dewantara', 'Rajawali', 'Cempaka', 'Flores', 'Sumatera', 'Kalimantan', 'Cipto', 'Fatmawati',
    ];

    private const KELURAHAN = [
        'Sukamaju', 'Harapan Jaya', 'Karang Anyar', 'Mekar Sari', 'Sidomulyo', 'Tanjung Raya', 'Bumi Asri', 'Cipta Karya', 'Margahayu', 'Sumber Rejo',
        'Pondok Indah', 'Rawa Bening', 'Kebon Jeruk', 'Tegal Sari', 'Wonorejo', 'Cibeunying', 'Sawah Besar', 'Lebak Bulus', 'Pasir Putih', 'Jati Baru',
    ];

    private const KECAMATAN = [
        'Cilandak', 'Coblong', 'Gubeng', 'Banyumanik', 'Mergangsan', 'Medan Baru', 'Panakkukang', 'Denpasar Barat', 'Lowokwaru', 'Bogor Tengah',
        'Sukmajaya', 'Cipondoh', 'Bekasi Selatan', 'Ilir Barat', 'Balikpapan Selatan', 'Kebayoran Baru', 'Sukajadi', 'Tegalsari', 'Tembalang', 'Umbulharjo',
    ];

    private const TEMPAT = [
        'Melati', 'Mawar', 'Kenanga', 'Bina Bangsa', 'Harapan', 'Cendekia', 'Pelita', 'Tunas Muda',
        'Insan Mandiri', 'Nusantara', 'Karya Utama', 'Bunda Pertiwi', 'Mutiara', 'Permata', 'Garuda', 'Teladan',
    ];

    /** @var list<string> */
    private array $kelas;

    /** @var array<string,list<string>> */
    private array $sekolah;

    public function __construct()
    {
        $this->kelas = ['1', '2', '3', '4', '5', '6'];
        for ($t = 7; $t <= 12; $t++) {
            foreach (range('A', 'K') as $r) {
                $this->kelas[] = $t . $r;
            }
        }

        $tk = [];
        foreach (array_slice(self::TEMPAT, 0, 12) as $p) {
            $tk[] = 'TK Pertiwi ' . $p;
            $tk[] = 'TK Islam Terpadu ' . $p;
            $tk[] = 'TK Kemala Bhayangkari ' . $p;
        }

        $sd = $smp = $sma = [];
        foreach (self::TEMPAT as $i => $p) {
            $sd[]  = 'SD Negeri 1 ' . $p;
            $sd[]  = 'SD Negeri 2 ' . $p;
            $smp[] = 'SMP Negeri 1 ' . $p;
            $smp[] = 'SMP Negeri 2 ' . $p;
            $sma[] = 'SMA Negeri 1 ' . $p;
            $sma[] = 'SMA Negeri 2 ' . $p;
            if ($i < 8) {
                $sd[]  = 'SD Islam Terpadu ' . $p;
                $smp[] = 'SMP Islam Terpadu ' . $p;
                $sma[] = 'SMK Negeri 1 ' . $p;
            }
        }

        $this->sekolah = ['tk' => $tk, 'sd' => $sd, 'smp' => $smp, 'sma' => $sma];
    }

    /**
     * @return list<array<string,string|null>> Baris siap dimasukkan ke tabel `siswa`.
     */
    public function buat(int $jumlah = 2600, int $seed = 2026): array
    {
        mt_srand($seed);

        $jumlahKelas = count($this->kelas);
        $dasar       = intdiv($jumlah, $jumlahKelas);
        $lebih       = $jumlah - $dasar * $jumlahKelas;

        $tahunAjar = $this->tahunAjarTerakhir();
        $barisKe   = 0;
        $putaranSekolah = ['tk' => 0, 'sd' => 0, 'smp' => 0, 'sma' => 0];
        $namaTerpakai   = [];
        $urutNik        = [];
        $hasil          = [];

        foreach ($this->kelas as $i => $kelas) {
            // Kelebihan dibagi merata ke seluruh kelas, bukan menumpuk di kelas awal.
            $isi     = $dasar + ((int) floor(($i + 1) * $lebih / $jumlahKelas) - (int) floor($i * $lebih / $jumlahKelas));
            $tingkat = (int) $kelas;
            $jenjang = $this->jenjang($tingkat);

            for ($j = 0; $j < $isi; $j++, $barisKe++) {
                $jk    = $barisKe % 2 === 0 ? 'L' : 'P';
                $tahun = $tahunAjar[$j % count($tahunAjar)];
                $mulai = (int) substr($tahun, 0, 4);

                $lahir = (new \DateTimeImmutable($mulai . '-07-01'))
                    ->modify('-' . (5 + $tingkat) . ' years')
                    ->modify('-' . mt_rand(0, 364) . ' days');

                $kota = self::KOTA[$barisKe % count(self::KOTA)];

                $daftar  = $this->sekolah[$jenjang];
                $sekolah = $daftar[$putaranSekolah[$jenjang]++ % count($daftar)];

                $dibuat = (new \DateTimeImmutable($mulai . '-07-01 07:30:00'))
                    ->modify('+' . mt_rand(0, 45) . ' days')
                    ->modify('+' . mt_rand(0, 540) . ' minutes');

                $umur  = (new \DateTimeImmutable($mulai . '-07-01'))->diff($lahir)->days / 365.25;
                $badan = $this->badan($umur, $jk, $barisKe, $seed);

                $hasil[] = [
                    'nama'          => $this->nama($jk, $namaTerpakai),
                    'nik'           => $this->nik($kota[2], $lahir, $jk, $urutNik),
                    'kelas'         => $kelas,
                    'asal_sekolah'  => $sekolah,
                    'jenis_kelamin' => $jk,
                    'tanggal_lahir' => $lahir->format('Y-m-d'),
                    'tahun_ajar'    => $tahun,
                    'alamat'        => $this->alamat($kota),
                    'no_hp'         => $this->noHp($barisKe, $seed),
                    'tinggi_badan'  => $badan['tinggi'],
                    'berat_badan'   => $badan['berat'],
                    'keterangan'    => $this->keterangan($barisKe, $seed),
                    'foto'          => null,
                    'created_at'    => $dibuat->format('Y-m-d H:i:s'),
                    'updated_at'    => $dibuat->format('Y-m-d H:i:s'),
                ];
            }
        }

        return $hasil;
    }

    /**
     * Nomor HP 13 digit: 62 + kode operator 3 digit + 8 digit. Dihitung dari nomor baris, bukan dari mt_rand,
     * supaya data lain (nama, NIK, alamat) tetap sama seperti sebelum kolom ini ada.
     */
    private function noHp(int $baris, int $seed): string
    {
        $operator = ['811', '812', '813', '821', '822', '823', '851', '852', '853', '857', '858', '877', '878', '881', '895', '896', '897', '898'];

        $o = $operator[crc32('hp-o-' . $seed . '-' . $baris) % count($operator)];
        $n = str_pad((string) (crc32('hp-n-' . $seed . '-' . $baris) % 100000000), 8, '0', STR_PAD_LEFT);

        return '62' . $o . $n;
    }

    /**
     * Bilangan acak antara 0 dan 1 yang ditentukan oleh nomor baris, bukan oleh mt_rand,
     * supaya kolom lain (nama, NIK, alamat, nomor HP) tidak berubah dari data sebelumnya.
     */
    private function acak(string $kunci, int $baris, int $seed): float
    {
        return (crc32($kunci . '-' . $seed . '-' . $baris) % 1000000) / 1000000;
    }

    /**
     * Mendekati sebaran normal dengan simpangan baku 1 (jumlah tiga bilangan acak).
     */
    private function normal(string $kunci, int $baris, int $seed): float
    {
        return ($this->acak($kunci . 'a', $baris, $seed) + $this->acak($kunci . 'b', $baris, $seed) + $this->acak($kunci . 'c', $baris, $seed) - 1.5) * 2;
    }

    /**
     * Interpolasi linear pada tabel [umur => nilai].
     *
     * @param array<int,float> $tabel
     */
    private function antara(array $tabel, float $umur): float
    {
        $kunci = array_keys($tabel);
        $umur  = max($kunci[0], min(end($kunci), $umur));
        for ($i = 0; $i < count($kunci) - 1; $i++) {
            if ($umur <= $kunci[$i + 1]) {
                $bagian = ($umur - $kunci[$i]) / ($kunci[$i + 1] - $kunci[$i]);

                return $tabel[$kunci[$i]] + $bagian * ($tabel[$kunci[$i + 1]] - $tabel[$kunci[$i]]);
            }
        }

        return $tabel[end($kunci)];
    }

    /**
     * Tinggi (cm) dan berat (kg) yang wajar untuk umur dan jenis kelamin: rata-rata anak Indonesia sekolah
     * dengan sebaran acak. Berat dihitung dari IMT, jadi selalu masuk akal terhadap tingginya.
     *
     * @return array{tinggi:string,berat:string}
     */
    private function badan(float $umur, string $jk, int $baris, int $seed): array
    {
        $tinggiLaki      = [6 => 116, 7 => 122, 8 => 128, 9 => 133, 10 => 138, 11 => 143, 12 => 149, 13 => 156, 14 => 163, 15 => 168, 16 => 171, 17 => 174, 18 => 175];
        $tinggiPerempuan = [6 => 115, 7 => 121, 8 => 127, 9 => 133, 10 => 139, 11 => 145, 12 => 151, 13 => 156, 14 => 159, 15 => 161, 16 => 162, 17 => 163, 18 => 163];
        $imt             = [6 => 15.3, 8 => 15.8, 10 => 16.7, 12 => 18.0, 14 => 19.2, 16 => 20.3, 18 => 21.0];

        $rata   = $this->antara($jk === 'L' ? $tinggiLaki : $tinggiPerempuan, $umur);
        $tinggi = max(85.0, min(200.0, $rata * (1 + 0.04 * $this->normal('tb', $baris, $seed))));

        $imtSiswa = max(12.0, min(32.0, $this->antara($imt, $umur) + 1.8 * $this->normal('bb', $baris, $seed)));
        $berat    = max(15.0, min(120.0, $imtSiswa * ($tinggi / 100) ** 2));

        return ['tinggi' => number_format($tinggi, 1, '.', ''), 'berat' => number_format($berat, 1, '.', '')];
    }

    private function keterangan(int $baris, int $seed): string
    {
        $daftar = [
            'Tidak ada catatan khusus',
            'Berkacamata, duduk di barisan depan',
            'Alergi kacang',
            'Alergi seafood',
            'Asma ringan, membawa inhaler',
            'Penerima Kartu Indonesia Pintar',
            'Penerima beasiswa prestasi',
            'Pindahan dari luar kota',
            'Ikut ekstrakurikuler Pramuka',
            'Ikut ekstrakurikuler futsal',
            'Ikut ekstrakurikuler paduan suara',
            'Diantar jemput orang tua',
            'Naik bus sekolah',
            'Wali murid: ibu',
            'Wali murid: kakek atau nenek',
            'Perlu perhatian khusus dalam pelajaran berhitung',
        ];

        return $daftar[crc32('ket-' . $seed . '-' . $baris) % count($daftar)];
    }

    private function jenjang(int $tingkat): string
    {
        return match (true) {
            $tingkat === 1  => 'tk',
            $tingkat <= 7   => 'sd',
            $tingkat <= 10  => 'smp',
            default         => 'sma',
        };
    }

    /**
     * Tiga tahun ajar terakhir, tahun ajar berjalan di urutan pertama. Tahun ajar baru dimulai Juli.
     *
     * @return list<string>
     */
    private function tahunAjarTerakhir(): array
    {
        $sekarang = new \DateTimeImmutable('now');
        $mulai    = (int) $sekarang->format('n') >= 7 ? (int) $sekarang->format('Y') : (int) $sekarang->format('Y') - 1;

        return [$mulai . '/' . ($mulai + 1), ($mulai - 1) . '/' . $mulai, ($mulai - 2) . '/' . ($mulai - 1)];
    }

    private function pilih(array $daftar): string
    {
        return $daftar[mt_rand(0, count($daftar) - 1)];
    }

    /**
     * @param array<string,bool> $terpakai
     */
    private function nama(string $jk, array &$terpakai): string
    {
        $depan    = $jk === 'L' ? self::LAKI : self::PEREMPUAN;
        $belakang = $jk === 'L' ? self::BELAKANG_LAKI : self::BELAKANG_PEREMPUAN;

        for ($percobaan = 0; $percobaan < 50; $percobaan++) {
            $bagian = [$this->pilih($depan)];
            if (mt_rand(0, 99) < 60) {
                $bagian[] = mt_rand(0, 1) ? $this->pilih(self::TENGAH) : $this->pilih($depan);
            }
            $bagian[] = $this->pilih($belakang);

            $nama = implode(' ', array_unique($bagian));
            if (! isset($terpakai[$nama])) {
                $terpakai[$nama] = true;

                return $nama;
            }
        }

        // Cadangan: semua kombinasi singkat sudah terpakai, tambahkan huruf pembeda.
        $nama = implode(' ', [$this->pilih($depan), $this->pilih($depan), $this->pilih($belakang)]) . ' ' . chr(65 + mt_rand(0, 25));
        $terpakai[$nama] = true;

        return $nama;
    }

    /**
     * NIK 16 digit: kode wilayah (4) + kecamatan (2) + tanggal lahir DDMMYY (perempuan: tanggal + 40) + nomor urut (4).
     *
     * @param array<string,int> $urut
     */
    private function nik(string $kodeKota, \DateTimeImmutable $lahir, string $jk, array &$urut): string
    {
        $kecamatan = str_pad((string) mt_rand(1, 30), 2, '0', STR_PAD_LEFT);
        $hari      = (int) $lahir->format('j') + ($jk === 'P' ? 40 : 0);
        $awal      = $kodeKota . $kecamatan . str_pad((string) $hari, 2, '0', STR_PAD_LEFT) . $lahir->format('my');

        $urut[$awal] = ($urut[$awal] ?? 0) + 1;

        return $awal . str_pad((string) $urut[$awal], 4, '0', STR_PAD_LEFT);
    }

    /**
     * @param array{0:string,1:string,2:string} $kota
     */
    private function alamat(array $kota): string
    {
        $jalan = mt_rand(0, 4) === 0 ? 'Gg. ' . $this->pilih(self::JALAN) . ' ' . mt_rand(1, 9) : 'Jl. ' . $this->pilih(self::JALAN);

        return sprintf(
            '%s No. %d, RT %02d/RW %02d, Kel. %s, Kec. %s, %s, %s',
            $jalan,
            mt_rand(1, 220),
            mt_rand(1, 15),
            mt_rand(1, 12),
            $this->pilih(self::KELURAHAN),
            $this->pilih(self::KECAMATAN),
            $kota[0],
            $kota[1]
        );
    }
}
