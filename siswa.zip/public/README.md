# Data Siswa (CodeIgniter 4)

Aplikasi data siswa untuk kelas 1 sampai 12. Setiap siswa punya:

- nama lengkap
- NIK (16 digit angka, tidak boleh kembar)
- foto (dipotong persegi 256x256 otomatis)
- kelas: 1 sampai 6, lalu 7A sampai 7K, 8A sampai 8K, dan seterusnya sampai 12A sampai 12K
- jenis kelamin (Laki-laki atau Perempuan)
- tanggal lahir
- asal sekolah (TK atau SD sebelumnya, boleh kosong)
- alamat
- nomor HP (13 digit angka)
- tinggi badan (cm) dan berat badan (kg), boleh satu angka desimal
- keterangan (catatan bebas, boleh kosong)
- periode tahun ajar, misalnya `2026/2027`

Fitur: tambah, ubah, hapus, cari nama, NIK, atau nomor HP, unduh Excel, dan empat filter: tab per tingkat (kelas 1 sampai 12), dropdown kelas persis (misalnya 7A), tahun ajar, dan asal sekolah. Angka di tab tingkat mengikuti filter tahun ajar dan asal sekolah.

Tombol **Unduh Excel** menghasilkan file `.xlsx` berisi semua siswa yang sesuai filter dan kata pencarian yang sedang aktif (bukan hanya halaman yang tampil). Kalau tidak ada filter, yang diunduh seluruh siswa. NIK dan nomor HP ditulis sebagai teks supaya tidak berubah menjadi 3,17E+15 di Excel. Tinggi dan berat ditulis sebagai angka, jadi bisa langsung dijumlah atau dirata-ratakan.

Folder ini hanya berisi file aplikasinya. Pasang di atas proyek CodeIgniter 4 yang baru.

## Kebutuhan

- PHP 8.1 atau lebih baru, dengan ekstensi `intl`, `mbstring`, `gd`, dan `zip` (untuk unduh Excel)
- Composer
- MySQL atau MariaDB

## Cara pasang (proyek baru)

1. Buat proyek CodeIgniter 4:

   ```
   composer create-project codeigniter4/appstarter siswa-app
   cd siswa-app
   ```

2. Salin isi folder `app/` dan `public/` dari zip ini ke dalam proyek tadi. Pilih "timpa" bila diminta (hanya `app/Config/Routes.php` yang tertimpa).

3. Salin `env` menjadi `.env`, lalu atur database:

   ```
   CI_ENVIRONMENT = development

   database.default.hostname = localhost
   database.default.database = db_siswa
   database.default.username = root
   database.default.password =
   database.default.DBDriver = MySQLi
   ```

   Buat dulu databasenya (`CREATE DATABASE db_siswa;`).

4. Atur zona waktu supaya pergantian tahun ajar (setiap Juli) mengikuti jam Indonesia. Di `app/Config/App.php`:

   ```php
   public string $appTimezone = 'Asia/Jakarta';
   ```

5. Aktifkan perlindungan CSRF. Di `app/Config/Filters.php`, bagian `$globals`, hapus tanda komentar pada `'csrf'`:

   ```php
   public array $globals = [
       'before' => [
           'csrf',
       ],
   ```

6. Daftarkan filter login. Di `app/Config/Filters.php`, tambahkan satu baris pada `$aliases`:

   ```php
   'auth' => \App\Filters\AuthFilter::class,
   ```

7. Jalankan migrasi, buat akun admin, lalu jalankan server:

   ```
   php spark migrate
   php spark pengguna:buat admin "Nama Admin"
   php spark serve
   
   ```
    VURPFzjQfqyt

   Perintah kedua menampilkan kata sandi acak satu kali saja. Catat. Menjalankannya lagi untuk nama pengguna yang sama mengatur ulang kata sandinya (tidak ada fitur "lupa sandi" lewat web).

8. Buka http://localhost:8080 (formulir publik) atau http://localhost:8080/loginpage (admin).

## Halaman dan hak akses

| Alamat | Siapa | Fungsi |
| --- | --- | --- |
| `/` atau `/daftar` | Publik, tanpa login | Siswa mengisi data sendiri. Hanya bisa menambah. |
| `/loginpage` | Admin | Halaman login |
| `/siswa` | Admin (role `admin`) | Lihat, cari, filter, tambah, ubah, hapus, dan Unduh Excel tanpa batas |

Pengaman formulir publik: CSRF, kolom jebakan untuk bot, batas 60 kiriman per jam per alamat IP (cukup longgar untuk satu kelas di wifi yang sama), validasi sama dengan admin, dan pesan NIK kembar yang tidak membocorkan data. Pengaman login: kata sandi disimpan sebagai hash, 5 kali salah mengunci 15 menit, ID sesi diganti setelah login, halaman admin tidak disimpan di cache browser, dan keluar lewat tombol (POST). Pakai HTTPS di produksi dan set `app.forceGlobalSecureRequests = true` di `.env`.

## Sudah pernah memasang versi sebelumnya?

Salin ulang seluruh isi `app/` dan `public/` dari zip ini (timpa), daftarkan alias `auth` di `Filters.php` (langkah 6 di atas), lalu jalankan:

```
php spark migrate
php spark pengguna:buat admin "Nama Admin"
```

Migrasi menambah kolom baru dan mengubah kolom `kelas` dari angka menjadi teks pendek (supaya bisa menyimpan `7A`). Nilai kelas lama 1 sampai 6 tetap utuh, dan data siswa yang sudah ada tidak berubah. Siswa lama akan menampilkan tanda "-" pada kolom baru (NIK, alamat, dan lainnya) sampai kamu mengisinya lewat tombol Ubah.

## Isi folder

| File | Fungsi |
| --- | --- |
| `app/Database/Migrations/2026-11-07-100000_CreateSiswa.php` | Membuat tabel `siswa` |
| `app/Database/Migrations/2026-11-07-110000_TambahKolomSiswa.php` | Menambah asal sekolah, jenis kelamin, tanggal lahir, tahun ajar |
| `app/Database/Migrations/2026-11-08-060000_TambahNikAlamatKelas.php` | Kelas jadi teks (7A-12K), menambah NIK (unik) dan alamat |
| `app/Database/Migrations/2026-11-08-070000_TambahNoHpSiswa.php` | Menambah nomor HP |
| `app/Database/Migrations/2026-11-08-130000_TambahTinggiBeratKeterangan.php` | Menambah tinggi badan, berat badan, dan keterangan |
| `app/Models/SiswaModel.php` | Model tabel `siswa` |
| `app/Controllers/Siswa.php` | Daftar, tambah, ubah, hapus, validasi, dan unggah foto |
| `app/Helpers/siswa_helper.php` | Inisial avatar, format tanggal Indonesia, daftar tahun ajar, daftar kelas 1-12K |
| `app/Views/siswa/index.php` | Halaman admin: formulir dan daftar siswa |
| `app/Views/siswa/_isian.php` | Kolom isian, dipakai bersama oleh halaman admin dan formulir publik |
| `app/Views/daftar.php`, `daftar_selesai.php` | Formulir publik dan halaman terima kasih |
| `app/Views/loginpage.php` | Halaman login admin |
| `app/Controllers/Daftar.php`, `Loginpage.php` | Formulir publik, login, dan logout |
| `app/Libraries/FormSiswa.php` | Validasi dan simpan foto, dipakai Siswa dan Daftar |
| `app/Filters/AuthFilter.php` | Penjaga halaman admin |
| `app/Commands/BuatPengguna.php` | `php spark pengguna:buat` |
| `app/Models/PenggunaModel.php`, migrasi `CreatePengguna` | Tabel akun admin |
| `app/Libraries/XlsxWriter.php` | Penulis file Excel (.xlsx) tanpa Composer, dipakai tombol Unduh Excel |
| `app/Libraries/GeneratorSiswa.php` | Pembuat data siswa dummy (tidak bergantung pada CodeIgniter) |
| `app/Database/Seeds/SiswaDummySeeder.php` | Mengisi tabel dengan 2.600 siswa dummy |
| `app/Config/Routes.php` | Rute aplikasi |
| `public/css/siswa.css` | Tampilan (terang dan gelap otomatis) |
| `public/uploads/siswa/` | Tempat foto yang diunggah |

## Data dummy untuk uji coba

Ada 2.600 siswa fiktif yang tersebar rata di 72 kelas (1-6, 7A-12K): 36 sampai 37 siswa per kelas, 1.300 laki-laki dan 1.300 perempuan, dan dibagi rata di tiga tahun ajar terakhir. Semua kolom terisi, termasuk nomor HP, tinggi, berat, dan keterangan, kecuali foto. Tinggi dan berat mengikuti umur dan jenis kelamin (misalnya kelas 1 sekitar 119 cm dan 22 kg, kelas 12 laki-laki sekitar 175 cm dan 63 kg), dengan IMT yang wajar.

Cara 1, lewat seeder (tabel `siswa` harus masih kosong, kalau tidak seeder berhenti sendiri):

```
php spark db:seed SiswaDummySeeder
```

Cara 2, lewat file `siswa_dummy_2600.sql` yang dikirim terpisah: buka phpMyAdmin, pilih database, lalu Import. Jalankan `php spark migrate` lebih dulu supaya tabelnya ada.

Untuk mengosongkan lagi sebelum memakai data asli: `TRUNCATE TABLE siswa;`

Sudah pernah mengimpor data dummy versi lama (sebelum ada nomor HP, tinggi, berat, dan keterangan)? Jalankan `php spark migrate`, kosongkan tabel dengan perintah di atas, lalu impor file SQL yang baru.

NIK, nama, dan alamat pada data dummy dibuat acak. Strukturnya meniru NIK asli (wilayah, tanggal lahir, nomor urut), jadi bisa saja kebetulan sama dengan NIK orang sungguhan. Jangan dipakai di luar uji coba.

## Aturan isian

- Nama, NIK, jenis kelamin, tanggal lahir, kelas, tahun ajar, alamat, nomor HP, tinggi badan, dan berat badan wajib diisi untuk data baru. Asal sekolah, keterangan, dan foto boleh kosong.
- Tinggi badan harus antara 50 dan 250 cm, berat badan antara 5 dan 250 kg. Batas ini sengaja longgar dan hanya menangkap salah ketik seperti 1255 atau 0.
- NIK harus tepat 16 digit angka dan tidak boleh sama dengan NIK siswa lain.
- Nomor HP harus tepat 13 digit angka (misalnya `6281234567890`, yaitu 62 diikuti 11 digit). Boleh sama dengan siswa lain, karena kakak-adik bisa memakai nomor orang tua yang sama.
- Pilihan kelas: 1 sampai 6, lalu 7A-7K sampai 12A-12K. Daftar ini dibuat di fungsi `daftar_kelas()` pada `app/Helpers/siswa_helper.php`; ubah di sana bila jumlah rombel berbeda.
- Tanggal lahir tidak boleh di masa depan dan tidak boleh lebih dari 25 tahun lalu.
- Pilihan tahun ajar mencakup satu tahun ke depan sampai lima tahun ke belakang. Tahun ajar baru dihitung mulai Juli. Rentang ini diatur di fungsi `daftar_tahun_ajar()` pada `app/Helpers/siswa_helper.php`.
- Jenis kelamin disimpan sebagai `L` atau `P`.

## Catatan

- Foto disimpan sebagai file di `public/uploads/siswa/` dengan nama acak. Hanya nama filenya yang masuk ke database. Pastikan folder itu bisa ditulis oleh web server.
- Bila ekstensi GD tidak aktif, foto tetap tersimpan tetapi tidak dikecilkan.
- Untuk produksi, ubah `CI_ENVIRONMENT` ke `production` dan arahkan document root ke folder `public/`.
- NIK dan alamat adalah data pribadi, apalagi untuk anak di bawah umur. Halaman daftar dan unduhan hanya untuk admin yang login; jaga kata sandi admin.
- Formulir publik menerima data dari siapa saja, jadi periksa data masuk secara berkala dan hapus kiriman yang tidak benar lewat halaman admin.
